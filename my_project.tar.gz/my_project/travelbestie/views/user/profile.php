<?php
use app\assets\LoginCss;
use yii\helpers\Html;
?>
<div class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-8">
					<div class="card">
						<div class="card-header" data-background-color="purple">
							<h4 class="title">Edit Profile</h4>
							<p class="category">Complete your profile</p>
						</div>
					
				
							<div class="card-content">
								
				
							</div>
						
					</div>
				</div>








<div class="col-md-4">
<div class="card card-profile">
<div class="card-avatar">
	<?= Html::img('@web/images/t1.jpg'); ?>
</div>

<div class="content">
	<h6 class="category text-gray">Welcome</h6>
		<h4 class="card-title"><?=Yii::$app->user->identity->first_name?></h4>
</div>
</div>
				</div>
				</div>
					</div>
				</div>