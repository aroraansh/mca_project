<?php
?>
<?php $this->beginPage() ?>
<?php $this->beginBody() ?>
<div class="faq">
	<div class="container">
		<h2 class="wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">Frequently Asked Questions</h2>
		<h3 class="wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">Payment-related</h3>
		<p class="wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.</p>
		<h3 class="wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">Cancellation-related</h3>
		<p>Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.</p>
			<ul class="animated wow fadeInUp animated" data-wow-duration="1200ms" data-wow-delay="500ms" style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
				<li>- Various versions have evolved over the years, sometimes by accident, sometimes on purpose</li>
				<li>- As opposed to using 'Content here, content here', making it look like readable English.</li>
				<li>- Sometimes by accident, sometimes on purpose Various versions have evolved over the years</li>
				<li>- Various versions have evolved over the years, sometimes by accident, sometimes on purpose</li>
				<li>- As opposed to using 'Content here, content here', making it look like readable English.</li>
				<li>- Sometimes by accident, sometimes on purpose Various versions have evolved over the years</li>
			</ul>
		<h3 class="wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">Insurance Related</h3>
		<p class="wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.</p>
		<h3 class="wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">Phone Booking & COD</h3>
		<p>Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.</p>
		<h3 class="wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">Refund-related</h3>
		<p>Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.</p>
			<ul class="animated wow fadeInUp animated" data-wow-duration="1200ms" data-wow-delay="500ms" style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
				<li>- Various versions have evolved over the years, sometimes by accident, sometimes on purpose</li>
				<li>- As opposed to using 'Content here, content here', making it look like readable English.</li>
				<li>- Sometimes by accident, sometimes on purpose Various versions have evolved over the years</li>
				<li>- Various versions have evolved over the years, sometimes by accident, sometimes on purpose</li>
				<li>- As opposed to using 'Content here, content here', making it look like readable English.</li>
				<li>- Sometimes by accident, sometimes on purpose Various versions have evolved over the years</li>
			</ul>
		<h3 class="wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">Booking-related</h3>
		<p class="wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.</p>
		<h3 class="wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">Ticket-related</h3>
		<p>Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.</p>
			<ul class="animated wow fadeInUp animated" data-wow-duration="1200ms" data-wow-delay="500ms" style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
				<li>- Various versions have evolved over the years, sometimes by accident, sometimes on purpose</li>
				<li>- As opposed to using 'Content here, content here', making it look like readable English.</li>
				<li>- Sometimes by accident, sometimes on purpose Various versions have evolved over the years</li>
				<li>- Various versions have evolved over the years, sometimes by accident, sometimes on purpose</li>
				<li>- As opposed to using 'Content here, content here', making it look like readable English.</li>
				<li>- Sometimes by accident, sometimes on purpose Various versions have evolved over the years</li>
			</ul>
		<h3 class="wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">General</h3>
		<p class="wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.</p>
	</div>
</div>
<?php $this->endBody() ?>
<?php $this->endPage() ?>