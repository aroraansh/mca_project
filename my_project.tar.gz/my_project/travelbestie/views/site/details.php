<?php
use yii\helpers\Html;
use yii\web\UrlManager;
use yii\helpers\Url;
?>
<div class="details">
	<div class="container">
		<div class="details-top">
			<div class="col-md-3 details-left wow fadeInLeft animated" data-wow-delay=".5s">
				<?= Html::img('@web/images/c5.jpg'); ?>
			</div>
			<div class="col-md-6 details-middle wow fadeInUp animated" data-wow-delay=".5s">
				<h3><a href="#">Estrela Do Mar Beach Resort - A Beach Property</a></h3>
				<p>Calangute Area, Goa</p>
				<li><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>reviews</li>
				<li><span class="glyphicon glyphicon-thumbs-up" aria-hidden="true"></span>guests recommended</li>
				<div class="clearfix"></div>
				<p>Amenities</p>
				<li><i class="fa fa-car"></i></li>
				<li><i class="fa fa-cutlery"></i></li>
				<li><i class="fa fa-suitcase"></i></li>
			</div>
			<div class="col-md-3 details-right wow fadeInRight animated" data-wow-delay=".5s">
				<h5>USD 700</h5>
				<a href="<?= Url::toRoute('site/rooms'); ?>" class="view">View Rooms</a>
			</div>
				<div class="clearfix"></div>
		</div>
		<div class="details-top">
			<div class="col-md-3 details-left wow fadeInLeft animated" data-wow-delay=".5s">
				<?= Html::img('@web/images/c3.jpg'); ?>
			</div>
			<div class="col-md-6 details-middle wow fadeInUp animated" data-wow-delay=".5s">
				<h3><a href="#">Estrela Do Mar Beach Resort - A Beach Property</a></h3>
				<p>Calangute Area, Goa</p>
				<li><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>reviews</li>
				<li><span class="glyphicon glyphicon-thumbs-up" aria-hidden="true"></span>guests recommended</li>
				<div class="clearfix"></div>
				<p>Amenities</p>
				<li><i class="fa fa-car"></i></li>
				<li><i class="fa fa-cutlery"></i></li>
				<li><i class="fa fa-suitcase"></i></li>
			</div>
			<div class="col-md-3 details-right wow fadeInRight animated" data-wow-delay=".5s">
				<h5>USD 700</h5>
				<a href="<?= Url::toRoute('site/rooms'); ?>" class="view">View Rooms</a>
			</div>
				<div class="clearfix"></div>
		</div>
		<div class="details-top">
			<div class="col-md-3 details-left wow fadeInLeft animated" data-wow-delay=".5s">
				<?= Html::img('@web/images/c4.jpg'); ?>
			</div>
			<div class="col-md-6 details-middle wow fadeInUp animated" data-wow-delay=".5s">
				<h3><a href="#">Estrela Do Mar Beach Resort - A Beach Property</a></h3>
				<p>Calangute Area, Goa</p>
				<li><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>reviews</li>
				<li><span class="glyphicon glyphicon-thumbs-up" aria-hidden="true"></span>guests recommended</li>
				<div class="clearfix"></div>
				<p>Amenities</p>
				<li><i class="fa fa-car"></i></li>
				<li><i class="fa fa-cutlery"></i></li>
				<li><i class="fa fa-suitcase"></i></li>
			</div>
			<div class="col-md-3 details-right wow fadeInRight animated" data-wow-delay=".5s">
				<h5>USD 700</h5>
				<a href="<?= Url::toRoute('site/rooms'); ?>" class="view">View Rooms</a>
			</div>
				<div class="clearfix"></div>
		</div>
		
	</div>
</div>