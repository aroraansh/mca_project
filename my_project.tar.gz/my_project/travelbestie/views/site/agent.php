<?php
?>
<?php $this->beginPage() ?>
<?php $this->beginBody() ?>
<div class="agent">
	<div class="container">
		<div class="col-md-6 agent-left wow fadeInDown animated"
			data-wow-delay=".5s">
			<p>Submit details we will call you back</p>
			<form>
				<input type="text" placeholder="Name"> <input type="text"
					placeholder="Email"> <input type="text" placeholder="Organization">
				<input type="text" placeholder="Phone"> <input type="text"
					placeholder="City"> <input type="text" placeholder="State">
				<textarea placeholder="Message"></textarea>
				<div class="sub">
					<input type="submit" value="Submit">
				</div>
			</form>
		</div>
		<div class="col-md-6 agent-right wow fadeInUp animated"
			data-wow-delay=".5s">

			<h3>About Bus</h3>
			<p>We’ve been travelling the world for over 5+ years, building a
				reputation for providing quality travel content that’s inspiring,
				engaging and informative. With all of our guides and features
				written and updated by a global network of expert travel writers
				that includes some of the best names in the business, we pride
				ourselves on producing content that stands out from the crowd. Find
				out more about our dedicated in-house team of editors here. Want to
				join us? Contact us for more details on how to apply.</p>
			<h3>Contact Us</h3>
			<p>
				<a href="mailto:example@email.com">hrdept@travelbestie.com</a>
			</p>
			<p>+91-999-111-2244</p>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
<?php $this->endBody() ?>
<?php $this->endPage() ?>