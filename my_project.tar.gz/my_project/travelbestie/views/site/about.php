<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'About';
?>
<?php $this->beginPage() ?>
<?php $this->beginBody() ?>
<div class="site-about">
   <div class="about">
	<div class="container">
		<div class="about-top wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">
			<h2>Our Story</h2>
			<p>1 bus ticketing and hotel room reservation platform, was founded in 2013 and is a part of the Group. We take pride in providing the platform to book bus tickets with zero booking charges. You can now choose from 10,000+ bus operators and 90,000 routes</p>
		</div>
		<div class="about-mid">
			<div class="col-md-6 abt-lft wow fadeInLeft animated" data-wow-delay=".5s">
				<h3>Culture</h3>
				<p>Every other day new partnerships are forged - all with the aim of adding more value and convenience for our customers. We have grown organically by opening offices in key metros and inorganically through our partnerships. We encourage customers to let us know of any routes or bus operators we don't have in our list. We go right ahead and make sure that by the next time a customer logs on, we have on offer what was demanded.</p>
				<p>Most importantly, it's a team that has fun at work. It's a team that is close knit. Everyone is on a first name basis and it wouldn't be uncommon to see people exchanging hi-fives on small achievements. Office outings are a regular phenomenon and dancing is a must.</p>
				<p>This helps us understand what we are doing wrong and what we are getting right. This feedback is invaluable for us. And we have you, our customers, to thank for taking time off to write back to us. There are times when there are hiccups. It's a learning organization, but we are learning the ropes like our lives depend on it.</p>
			</div>
			<div class="col-md-6 abt-lft wow fadeInRight animated" data-wow-delay=".5s">
				<h3>Technology</h3>
				<p>Every other day new partnerships are forged - all with the aim of adding more value and convenience for our customers. We have grown organically by opening offices in key metros and inorganically through our partnerships. We encourage customers to let us know of any routes or bus operators we don't have in our list. We go right ahead and make sure that by the next time a customer logs on, we have on offer what was demanded.</p>
				<p>Most importantly, it's a team that has fun at work. It's a team that is close knit. Everyone is on a first name basis and it wouldn't be uncommon to see people exchanging hi-fives on small achievements. Office outings are a regular phenomenon and dancing is a must.</p>
				<p>This helps us understand what we are doing wrong and what we are getting right. This feedback is invaluable for us. And we have you, our customers, to thank for taking time off to write back to us. There are times when there are hiccups. It's a learning organization, but we are learning the ropes like our lives depend on it.</p>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="ab-btm">
			<div class="col-md-8 ab-lt wow fadeInLeft animated" data-wow-delay=".5s">
				<h3>Testimonials</h3>
				<div class="ab-tp">
					<p>"Its very good concept of booking bus ticket online, I got the number from a helpline at 2.00pm & by 3.30 I got my tickets booked by 3.00 for the bus at 9.00pm, when other bus service."</p>
					<h5>- John Doe</h5>
					<h6>- Orlando</h6>
				</div>
				<div class="ab-tp">
					<p>"Its very good concept of booking bus ticket online, I got the number from a helpline at 2.00pm & by 3.30 I got my tickets booked by 3.00 for the bus at 9.00pm, when other bus service."</p>
					<h5>- Mark Paul</h5>
					<h6>- New Orleans</h6>
				</div>
				<div class="ab-tp">
					<p>"Its very good concept of booking bus ticket online, I got the number from a helpline at 2.00pm & by 3.30 I got my tickets booked by 3.00 for the bus at 9.00pm, when other bus service."</p>
					<h5>- Levin</h5>
					<h6>- Designer</h6>
				</div>
			</div>
			<div class="col-md-4 ab-rt wow fadeInRight animated" data-wow-delay=".5s">
				<h3>Our Lists</h3>
					<ul>
						<li><a href="#">At vero eos et accusamus et iusto odio</a></li>
						<li><a href="#">Egnissi mos ducimus qui blanditiis</a></li>
						<li><a href="#">Rraesentium voluptatum deleniti atque</a></li>
						<li><a href="#">At vero eos et accusamus et iusto odio</a></li>
						<li><a href="#">Egnissi mos ducimus qui blanditiis</a></li>
						<li><a href="#">Rraesentium voluptatum deleniti atque</a></li>
						<li><a href="#">At vero eos et accusamus et iusto odio</a></li>
						<li><a href="#">Egnissi mos ducimus qui blanditiis</a></li>
						<li><a href="#">Rraesentium voluptatum deleniti atque</a></li>
						<li><a href="#">At vero eos et accusamus et iusto odio</a></li>
						<li><a href="#">Egnissi mos ducimus qui blanditiis</a></li>
						<li><a href="#">Rraesentium voluptatum deleniti atque</a></li>
						<li><a href="#">Egnissi mos ducimus qui blanditiis</a></li>
					</ul>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
</div>
<?php $this->endBody() ?>
<?php $this->endPage() ?>