<?php
use yii\helpers\Html;

use yii\helpers\Url;
?>

<div class="bus-tp">
	<p>Fare starts from : USD. 600</p>
	<h2>Buses from California to Alabama</h2>
	<div class="clearfix"></div>
</div>
<!--- /bus-tp ---->
<!--- bus-btm ---->
<div class="bus-btm">
	<div class="container">
		<ul>
			<li class="trav"><a href="#">Travels</a></li>
			<li class="dept"><a href="#">Depart</a></li>
			<li class="arriv"><a href="#">Arrive</a></li>
			<li class="seat"><a href="#">Seats</a></li>
			<li class="fare"><a href="#">Fare</a></li>
			<div class="clearfix"></div>
		</ul>
	</div>
</div>
<!--- /bus-btm ---->
<!--- bus-midd ---->
<div class="bus-midd wow zoomIn animated animated" data-wow-delay=".5s"
	style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">
	<div class="container">
		<!--- ul-first  ---->

		<ul class="first">
			<li class="trav">
				<div class="bus-ic">
					<?= Html::img('@web/images/bus.png'); ?>
				</div>
				<div class="bus-txt">
					<h4>New York Charter</h4>
					<p>A/C Sleeper (1+1)</p>
				</div>
				<div class="clearfix"></div>
			</li>
			<li class="dept">
				<div class="bus-ic1">
					<i class="fa fa-clock-o"></i>
				</div>
				<div class="bus-txt1">
					<h4>08:10 PM</h4>
					<p>Duration</p>
				</div>
				<div class="clearfix"></div>
			</li>
			<li class="arriv">
				<div class="bus-txt2">
					<h4>
						<a href="#">6:10 AM</a>
					</h4>
					<p>10:00 Hrs</p>
				</div>
			</li>
			<li class="seat">
				<div class="bus-ic3">
					<?= Html::img('@web/images/seat.png'); ?>
				</div>
				<div class="bus-txt3">
					<h4>4 seats</h4>
					<p>Window 4</p>
				</div>
				<div class="clearfix"></div>
			</li>
			<li class="fare">
				<div class="bus-txt4">
					<h5>
						USD 900
						</h4>
						<div class="sear">
							<form action="<?= Url::toRoute('site/bus'); ?>">
								<button class="seabtn">Book</button>
							</form>
						</div>
			
			</li>
			<div class="clearfix"></div>
		</ul>
		<!--- /ul-first  ---->
		<!--- ul-first-1 ---->
		<ul class="first">
			<li class="trav">
				<div class="bus-ic">
					<?= Html::img('@web/images/bus.png'); ?>
				</div>
				<div class="bus-txt">
					<h4>Chicago Charter</h4>
					<p>A/C Sleeper (1+1)</p>
				</div>
				<div class="clearfix"></div>
			</li>
			<li class="dept">
				<div class="bus-ic1">
					<i class="fa fa-clock-o"></i>
				</div>
				<div class="bus-txt1">
					<h4>
						<a href="#">08:10 PM</a>
					</h4>
					<p>Duration</p>
				</div>
				<div class="clearfix"></div>
			</li>
			<li class="arriv">
				<div class="bus-txt2">
					<h4>
						<a href="#">6:10 AM</a>
					</h4>
					<p>10:00 Hrs</p>
				</div>
			</li>
			<li class="seat">
				<div class="bus-ic3">
					<?= Html::img('@web/images/seat.png'); ?>
				</div>
				<div class="bus-txt3">
					<h4>3 seats</h4>
					<p>Window 4</p>
				</div>
				<div class="clearfix"></div>
			</li>
			<li class="fare">
				<div class="bus-txt4">
					<h5>USD 750</h5>
					<div class="sear">
						<form action="<?= Url::toRoute('site/bus'); ?>">
							<button class="seabtn">Book</button>
						</form>
					</div>
				</div>
			</li>
			<div class="clearfix"></div>
		</ul>
		<!--- /ul-first-1 ---->
		<!--- ul-first-2 ---->
		<ul class="first">
			<li class="trav">
				<div class="bus-ic">
					<?= Html::img('@web/images/bus.png'); ?>
				</div>
				<div class="bus-txt">
					<h4>Houston Charter</h4>
					<p>A/C Sleeper (1+1)</p>
				</div>
				<div class="clearfix"></div>
			</li>
			<li class="dept">
				<div class="bus-ic1">
					<i class="fa fa-clock-o"></i>
				</div>
				<div class="bus-txt1">
					<h4>
						<a href="#">08:10 PM</a>
					</h4>
					<p>Duration</p>
				</div>
				<div class="clearfix"></div>
			</li>
			<li class="arriv">
				<div class="bus-txt2">
					<h4>
						<a href="#">6:10 AM</a>
					</h4>
					<p>10:00 Hrs</p>
				</div>
			</li>
			<li class="seat">
				<div class="bus-ic3">
					<?= Html::img('@web/images/seat.png'); ?>
				</div>
				<div class="bus-txt3">
					<h4>8 seats</h4>
					<p>Window 4</p>
				</div>
				<div class="clearfix"></div>
			</li>
			<li class="fare">
				<div class="bus-txt4">
					<h5>
						USD 1050
						</h4>
						<div class="sear">
							<form action="<?= Url::toRoute('site/bus'); ?>">
								<button class="seabtn">Book</button>
							</form>
						</div>
				
				</div>
			</li>
			<div class="clearfix"></div>
		</ul>
	</div>
</div>
<!--- /bus-midd ---->
<!--- footer-top ---->
