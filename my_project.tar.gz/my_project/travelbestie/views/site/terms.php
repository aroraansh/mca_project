<?php
?>
<?php $this->beginPage() ?>
<?php $this->beginBody() ?>
<div class="terms">
	<div class="container">
		<h3 class="wow fadeInDown animated animated" data-wow-delay=".5s">Terms
			and Conditions - Buses</h3>

		<p class="wow fadeInDown animated animated" data-wow-delay=".5s">
			Customers who want to use any of the services of Travel Bestie. have
			to hold - unless otherwise provided by the pricing regulation -an
			appropriate ticket for the given line which can be validated or have
			to possess an appropriate pass, travelling certificate or a document
			certifying their right to travel free of charge.</p>
		<p class="wow fadeInDown animated animated" data-wow-delay=".5s">
			Passengers using the services of Travel Bestie. (during boarding and
			alighting, waiting for the vehicle and travelling) are obliged to
			behave in a way that does not endanger the safety of traffic,
			vehicles, stations and equipments and the other passengers'
			convenience or peace.</p>
		<p class="wow fadeInDown animated animated" data-wow-delay=".5s">
			<span>1. </span>Every passenger is permitted to carry maximum 2
			pieces of luggage free of charge, the sizes of which must not exceed
			40x50x80 cm or 20x20x200 cm which can be carried by one person and
			which must not obstruct entry to or exit from the vehicle, It is
			permitted to carry one sledge, one pair of skis, one wrapped sapling
			tree or a pram.
		</p>
		<p class="wow fadeInDown animated animated" data-wow-delay=".5s">
			<span>2. </span>A dog (regardless of its size) may be transported on
			the vehicles on the condition of the purchase of a full-price ticket
			or pass for the dog for the given distance. A single ticket or one of
			the discount coupon tickets is also valid on the entire length of HÉV
			(suburban railway) lines.
		</p>
		<p class="wow fadeInDown animated animated" data-wow-delay=".5s">
			<span>3. </span>In order to ensure travel safety it is forbidden to
			board a vehicle or alight from it after the starting warning has
			sounded, and you must not obstruct the doors while they are closing.
		</p>
		<p class="wow fadeInDown animated animated" data-wow-delay=".5s">
			<span>4. </span>It is forbidden to listen to radios or other sound
			equipment within the vehicles or within the areas of metro and HÉV
			stations at a volume that may disturb other passengers.
		</p>
		<p class="wow fadeInDown animated animated" data-wow-delay=".5s">
			<span>5. </span>In order to protect public health, persons with
			infectious diseases are not permitted to travel in the vehicles.
		</p>
		<p class="wow fadeInDown animated animated" data-wow-delay=".5s">
			<span>6. </span>The Website is a marketplace, which merely lists the
			inventory of bus operators who are registered with the Website, but
			does not own the services per se. Hence, the limited role of the
			Website is to connect You with the bus operator and vice versa.
		</p>
		<p class="wow fadeInDown animated animated" data-wow-delay=".5s">
			<span>7. </span>In light of the foregoing, You agree that any
			liability in relation to any services being offered on the Website in
			accordance with the applicable laws shall be that of the bus operator
			and not Travel Bestie. In case of any deficiency of service, You
			agree to pursue any such action arising from such deficiency of
			service against the bus operator and not the Travel Bestie.
		</p>

		<div class="terms-bottom">
			<h3 class="wow fadeInDown animated animated" data-wow-delay=".5s">Terms
				and Conditions - Hotels</h3>
			<p class="wow fadeInDown animated animated" data-wow-delay=".5s">Travel
				Bestie.com provides a platform to temporary accommodation providers
				(“Service Providers”)to list their inventory on the website and
				allows you to select and reserve Accommodation,
				based on the customer’spersonal preferences(“Service”).</p>
			<p class="wow fadeInDown animated animated" data-wow-delay=".5s">The
				term ‘temporary accommodation’ includes but is not limited to
				hotels, motels, home-stays, hostels and bed & breakfast
				(collectively “Accommodation(s)”).</p>

			<p class="wow fadeInDown animated animated" data-wow-delay=".5s">Travel Bestie
				acts as an intermediary between the customer and the Service
				Providers, that have listed their Accommodation on the website, for
				the purposes of reservation of such Accommodation. A reservation
				made through the website, istherefore a bipartite contract between
				the customer and the Service Provider. Therefore, the contractual
				terms and conditions of the Service Provider shall be applicable
				once areservation has been made through the website. Travel Bestie only
				undertakes to share the relevant details of the customer to the
				Service Provider and a confirmation email on the Service Provider’s
				behalf to the customer.</p>
			<p class="wow fadeInDown animated animated" data-wow-delay=".5s">
				While rendering the Services, all the information, related to a
				particular Service Provider, such as the tariff, availability,
				facilities & amenities, representative images (if any), etc.,of a
				particular Accommodation, displayed on the website, are attributable
				to the respective Service Providers themselves and they are fully
				responsible for updating the same. The website cannot be held liable
				for any discrepancy in the said information.Travel Bestie does not
				guarantee the accuracy, completeness, correctness, suitability etc.,
				of such information to the customer and cannot be held responsible
				in case the information is erroneous, inaccurate, untrue,
				incomplete, or misleading in nature. The listing of anAccommodation
				on the website does not constitute and should not be regarded as a
				recommendation and/or an endorsement of the quality, service level,
				qualification or rating of any Accommodation made available, to the
				customer.</p>
			<h6 class="wow fadeInDown animated animated" data-wow-delay=".5s">Pricing
				and tariff</h6>
			<p class="wow fadeInDown animated animated" data-wow-delay=".5s">
				<span>1. </span>Accommodation(s) may be available on other websites
				at tariff lower than those displayed on the website, for any
				specific period. However, such lower tariff offeredby the Service
				Provider/s could be subject to specific terms and conditions with
				respect to refunds, cancellations, etc. customers are advised to
				check the Accommodation and tariff details, Accommodation policy,
				booking and cancellation policy, thoroughly before making a
				reservation of an Accommodation.
			</p>
			<p class="wow fadeInDown animated animated" data-wow-delay=".5s">
				<span>2. </span>Obvious errors and mistakes (including but not
				limited to misprints) are not binding.
			</p>
			<p class="wow fadeInDown animated animated" data-wow-delay=".5s">
				<span>3. </span>All special offers and promotions on the website are
				marked as such.
			</p>

			<h3 class="wow fadeInDown animated animated" data-wow-delay=".5s">
				Cancellation Policy</h3>
			<p class="wow fadeInDown animated animated" data-wow-delay=".5s">
				<span>1. </span>The cancellation policy (“Cancellation Policy”)
				displayed on our website is very dynamic and may change in the
				duration between the date of making reservation and the date of
				customer’s stay at the Accommodation. The Cancellation Policy
				prevailing at the time of check-in/cancellation of the reservation
				by the customer will be the applicable policy.
			</p>
			<p class="wow fadeInDown animated animated" data-wow-delay=".5s">
				<span>2. </span>Once a reservation is made, the customer agrees to
				the terms and conditions of the Service Provider, including those
				related to cancellation and refunds. The Service Provider may have
				its own cancellation policy.
			</p>
			<p class="wow fadeInDown animated animated" data-wow-delay=".5s">
				<span>3. </span>The general cancellation and no-show policy of each
				the respective Service Provider is made available on the website on
				the Accommodation information page, and displayed during the time
				when the customer makes the reservation and may also be sent to the
				customer, in the email confirming the reservation.
			</p>
			<p class="wow fadeInDown animated animated" data-wow-delay=".5s">
				<span>4. </span>For cancellation of reservation(s) made after
				availing any Offer mentioned in heading IV of these Terms, the
				cancellation charges are calculated on total price before the
				application of Offer. For such reservations, an additional
				cancellation charge, which will be deducted from the refund amount,
				after making all the deductions in accordance with the Service
				Provider’s cancellation policy.
			</p>
			<p class="wow fadeInDown animated animated" data-wow-delay=".5s">
				<span>5. </span>For cancellation of a reservation, the customer
				shall make a verbal and/or a written request to our customer care
				representatives or make such cancellation through the website or the
				Travel Bestie mobile application.
			</p>
			<p class="wow fadeInDown animated animated" data-wow-delay=".5s">
				<span>6. </span>Only those cancellation requests that are
				communicated through phone or via email to our customer support
				team, or through our website or mobile application, shall be
				entertained. Travel Bestie shall not be liable to entertain any
				cancellation requests made directly to the Service Provider without
				intimating Travel Bestie in writing or over the phone call.
			</p>
			<p class="wow fadeInDown animated animated" data-wow-delay=".5s">
				<span>7. </span>If the customer or his/her guests do not turn up at
				the Accommodation (“No-Show”), pursuant to making a reservation, the
				customer shall continue to be liable for the entire tariff displayed
				at the time of making the reservation, and the Service Provider may
				debit the amount from the customer’s credit card directly.
			</p>
			<p class="wow fadeInDown animated animated" data-wow-delay=".5s">
				PLEASE BE AWARE THAT BY DISPLAYING INFORMATION ABOUT ASERVICE
				PROVIDER, Travel Bestie IS NOT SUGGESTING THAT, AVAILINGTHEIR SERVICES IS
				ADVISABLE OR RISK FREE. Travel Bestie IS NOTLIABLE FOR ANY DAMAGES AND/OR
				LOSSES THAT MAY RESULTFROM THE CUSTOMER DECIDING TO AVAIL SUCH
				SERVICES. ANYSUCH RESERVATION MADE BY THE CUSTOMER IS AT
				THECUSTOMER’S SOLE RISK BASIS THE CUSTOMER’S INDEPENDENT JUDGEMENT.</p>
		</div>
	</div>
</div>

<?php $this->endBody() ?>
<?php $this->endPage() ?>