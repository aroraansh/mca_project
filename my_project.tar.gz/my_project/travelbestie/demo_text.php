<?php
?>
<div class="modal-body modal-spa">
	<div class="login-grids">
		<div class="login">
			<div class="login-left">
				<ul>

				</ul>
				<ul>
					<li><a class="fb" href="#"><i></i>Sign in with Facebook</a></li>
					<li><a class="goog" href="#"><i></i>Sign in with Google</a></li>
					<li><a class="linkin" href="#"><i></i>Sign in with Tweeter</a></li>
				</ul>
			</div>




			<p>
				By logging in you agree to our <a
					href="<?= Url::toRoute('site/terms') ?>">Terms and Conditions</a>
				and <a href="<?= Url::toRoute('site/privacy') ?>">Privacy Policy</a>
			</p>
			<p>
				Already have a account then <a
					href="<?= Url::toRoute('user/login') ?>">Login</a>
			</p>
		</div>
	</div>
</div>
</div>





<div class="user-update">

    <?=$this->render('_signupform', ['model' => $model])?>
										
</div>