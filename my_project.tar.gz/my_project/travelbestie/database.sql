-- -------------------------------------------

--1. TABLE `user`

-- -------------------------------------------
drop table if exists `user`;
create table if not exists `user`(
`id` int(11) auto_increment NOT null,
`first_name` varchar(255) NOT null,
`last_name` varchar(255) default null,
`email` varchar(255) not null unique,
`password` varchar(255) not null,
`date_of_birth` varchar(255) default null,
`gender` int(11) default '0',
`contact_no` varchar(255) default null,
`address` varchar(512) default null,
`latitude` varchar(512) default null,
`lognitude` varchar(512) default null,
`city` varchar(255) default null,
`country` varchar(255) default null,
`pin_code` varchar(255) default null,
`language` varchar(255) default null,
`email_verified` tinyint(1) default '0',
`profile_picture` varchar(255) default null,
`tos` int(11) default null,
`role_id` int(11) default null,
`state_id` int(11) default null,
`type_id` int(11) default '0',
`last_visit_time` datetime  default null,
`last_action_time` datetime default null,
`last_password_change` datetime default null,
`login_error_count` int(11) default null,
`activation_key` varchar(128) default null,
`timezone` varchar(255) default null,
`created_on` datetime NOT NULL,
`updated_on` datetime default null,
`created_by_id` int(11) default null, 
primary key(id)
);



-- -------------------------------------------

--2. TABLE `City`

-- -------------------------------------------
drop table if exists `city`;
create table if not exists `city`(
`id` int(11) not null,
`name` varchar(255) not null unique,
`state` varchar(255) not null default null,
`state_id` int(11) default null,
`created_on` datetime NOT NULL,
`updated_on` datetime default null,
`created_by_id` int(11) default null, 
primary key(id),
KEY `fk_city_create_user` (`created_by_id`),
CONSTRAINT `fk_city_create_user` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`) 
);



-- -------------------------------------------

--3. TABLE `Hotels`

-- -------------------------------------------
drop table if exists `hotels`;
create table if not exists `hotels`(
`id` int(11) not null,
`name` varchar(255) not null unique,
`location` varchar(255) not null default null,
`star` int(11) default null,
`price_per_room` int(11) not null default null,
`state_id` int(11) default null,
`created_on` datetime NOT NULL,
`updated_on` datetime default null,
`created_by_id` int(11) default null, 
primary key(id),
key `fk_hotels_create_city` (`create_by_id`),
constraint `fk_hotels_create_user` foreign key (`created_by_id`) references `city` (id)
);



-- -------------------------------------------

--4. TABLE `Details`

-- -------------------------------------------
drop table if exists `details`;
create table if not exists `details`(
`id` int(11) not null,
`name` varchar(255) not null,
`email` varchar(255) not null,
`city` varchar(255) not null,
`hotel` varchar(255) not null,
`check_in_date` date not null,
`check_out_date` date not null,
`total_room` int(11) not null,
`booking_date` date not null,
`state_id` int(11) default null,
`created_on` datetime NOT NULL,
`updated_on` datetime default null,
`created_by_id` int(11) default null, 
primary key(id),
KEY `fk_details_create_user` (`created_by_id`),
CONSTRAINT `fk_details_create_user` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`) 
);



-- -------------------------------------------

--5. TABLE `Feedback`

-- -------------------------------------------
drop table if exists `feedback`;
create table if not exists `feedback`(
`id` int(11) not null,
`name` varchar(255) not null,
`email` varchar(255) not null,
`message` varchar(255) not null,
`reply` varchar(255) default null,
primary key(id)
);


-- -------------------------------------------

--6. TABLE `History`

-- -------------------------------------------
drop table if exists `history`;
create table if not exists `history`(
`id` int(11) not null,
`name` varchar(255) not null,
`email` varchar(255) not null,
`city` varchar(255) not null,
`location` varchar(255) not null,
`hotel` varchar(255) not null,
`check_in_date` date not null,
`check_out_date` date not null,
`room` int(11) not null,
`booking_date` date not null,
primary key(id)
);


-- -------------------------------------------

--6. TABLE `Buses`

-- -------------------------------------------
drop table if exists `buses`;
create table if not exists `buses`(

);


