<?php
namespace app\models;

use Yii;

/**
 * This is the model class for table "user".
 *
 * @property integer $id
 * @property string $first_name
 * @property string $last_name
 * @property string $email
 * @property string $password
 * @property string $date_of_birth
 * @property integer $gender
 * @property string $contact_no
 * @property string $address
 * @property string $latitude
 * @property string $lognitude
 * @property string $city
 * @property string $country
 * @property string $pin_code
 * @property string $language
 * @property integer $email_verified
 * @property string $profile_picture
 * @property integer $tos
 * @property integer $role_id
 * @property integer $state_id
 * @property integer $type_id
 * @property string $last_visit_time
 * @property string $last_action_time
 * @property string $last_password_change
 * @property integer $login_error_count
 * @property string $activation_key
 * @property string $timezone
 * @property string $created_on
 * @property string $updated_on
 * @property integer $created_by_id
 *
 * @property Booking[] $bookings
 * @property City[] $cities
 * @property Feedback[] $feedbacks
 */
class User extends \yii\db\ActiveRecord implements \yii\web\IdentityInterface
{

    const ROLE_ADMIN = 0;

    const ROLE_USER = 1;

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'user';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [
                [
                    'first_name',
                    'email',
                    'password',
                    'role_id',
                    'created_on'
                ],
                'required'
            ],
            [
                [
                    'gender',
                    'email_verified',
                    'tos',
                    'role_id',
                    'state_id',
                    'type_id',
                    'login_error_count',
                    'created_by_id'
                ],
                'integer'
            ],
            [
                [
                    'last_visit_time',
                    'last_action_time',
                    'last_password_change',
                    'created_on',
                    'updated_on'
                ],
                'safe'
            ],
            [
                [
                    'first_name',
                    'last_name',
                    'email',
                    'password',
                    'date_of_birth',
                    'contact_no',
                    'city',
                    'country',
                    'pin_code',
                    'language',
                    'profile_picture',
                    'timezone'
                ],
                'string',
                'max' => 255
            ],
            [
                [
                    'address',
                    'latitude',
                    'lognitude'
                ],
                'string',
                'max' => 512
            ],
            [
                [
                    'activation_key'
                ],
                'string',
                'max' => 128
            ],
            [
                [
                    'email'
                ],
                'unique'
            ]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'first_name' => 'First Name',
            'last_name' => 'Last Name',
            'email' => 'Email',
            'password' => 'Password',
            'date_of_birth' => 'Date Of Birth',
            'gender' => 'Gender',
            'contact_no' => 'Contact No',
            'address' => 'Address',
            'latitude' => 'Latitude',
            'lognitude' => 'Lognitude',
            'city' => 'City',
            'country' => 'Country',
            'pin_code' => 'Pin Code',
            'language' => 'Language',
            'email_verified' => 'Email Verified',
            'profile_picture' => 'Profile Picture',
            'tos' => 'Tos',
            'role_id' => 'Role ID',
            'state_id' => 'State ID',
            'type_id' => 'Type ID',
            'last_visit_time' => 'Last Visit Time',
            'last_action_time' => 'Last Action Time',
            'last_password_change' => 'Last Password Change',
            'login_error_count' => 'Login Error Count',
            'activation_key' => 'Activation Key',
            'timezone' => 'Timezone',
            'created_on' => 'Created On',
            'updated_on' => 'Updated On',
            'created_by_id' => 'Created By ID'
        ];
    }

    public function beforeValidate()
    {
        if (! isset($this->created_on))
            $this->created_on = date('Y-m-d H:i:s');
//         if (!isset($this->created_by_id))
//             $this->created_by_id = \Yii::$app->user->id;
        return parent::beforeValidate();
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    /*
     * public function getBookings()
     * {
     * return $this->hasMany(Booking::className(), ['created_by_id' => 'id']);
     * }
     */
    
    /**
     *
     * @return \yii\db\ActiveQuery
     */
    /*
     * public function getCities()
     * {
     * return $this->hasMany(City::className(), ['created_by_id' => 'id']);
     * }
     */
    
    /**
     *
     * @return \yii\db\ActiveQuery
     */
    /*
     * public function getFeedbacks()
     * {
     * return $this->hasMany(Feedback::className(), ['created_by_id' => 'id']);
     * }
     */
    
    /*
     * public $id;
     * public $username;
     * public $password;
     * public $authKey;
     * public $accessToken;
     */
    
    /*
     * private static $users = [
     * '100' => [
     * 'id' => '100',
     * 'username' => 'admin',
     * 'password' => 'admin',
     * 'authKey' => 'test100key',
     * 'accessToken' => '100-token',
     * ],
     * '101' => [
     * 'id' => '101',
     * 'username' => 'demo',
     * 'password' => 'demo',
     * 'authKey' => 'test101key',
     * 'accessToken' => '101-token',
     * ],
     * ];
     */
    
    /**
     * @inheritdoc
     */
    public static function findIdentity($id)
    {
        // return isset(self::$users[$id]) ? new static(self::$users[$id]) : null;
        return static::findOne([
            'id' => $id
        ]);
    }

    /**
     * @inheritdoc
     */
    public static function findIdentityByAccessToken($token, $type = null)
    {
        echo "findIdentityByAccessToken";
        return static::findOne([
            'auth_key' => $token
            // 'state_id' => self::STATE_ACTIVE
        ]);
    }

    /**
     * Finds user by username
     *
     * @param string $username
     * @return static|null
     */
    public static function findByUsername($username)
    {
        return static::findOne([
            'email' => $username
        ]);
    }

    public function getLoginUrl()
    {
        return Yii::$app->urlManager->createAbsoluteUrl([
            'user/login'
        ]);
    }

    /**
     * @inheritdoc
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @inheritdoc
     */
    public function getAuthKey()
    {
        return $this->activation_key;
    }

    /**
     * @inheritdoc
     */
    public function validateAuthKey($authKey)
    {
        return $this->activation_key === $authKey;
    }

    /**
     * Validates password
     *
     * @param string $password
     *            password to validate
     * @return bool if password provided is valid for current user
     */
    public function setPassword($password)
    {
        $this->password = $this->hashPassword($password);
        ;
    }

    public function validatePassword($password)
    {
        return $this->password === $this->hashPassword($password);
    }

    public function hashPassword($password)
    {
        /* if (YII_ENV == 'dev') */
        return md5($password);
        // return Yii::$app->security->generatePasswordHash(yii::$app->name . $password);
    }
}
