-- -------------------------------------------

--1. TABLE `user`

-- -------------------------------------------
drop table if exists `user`;
create table if not exists `user`(
`id` int(11) auto_increment NOT null,
`first_name` varchar(255) NOT null,
`last_name` varchar(255) default null,
`email` varchar(255) not null unique,
`password` varchar(255) not null,
`date_of_birth` varchar(255) default null,
`gender` int(11) default '0',
`contact_no` varchar(255) default null,
`address` varchar(512) default null,
`latitude` varchar(512) default null,
`lognitude` varchar(512) default null,
`city` varchar(255) default null,
`country` varchar(255) default null,
`pin_code` varchar(255) default null,
`language` varchar(255) default null,
`email_verified` tinyint(1) default '0',
`profile_picture` varchar(255) default null,
`tos` int(11) default null,
`role_id` int(11) default null,
`state_id` int(11) default null,
`type_id` int(11) default '0',
`last_visit_time` datetime  default null,
`last_action_time` datetime default null,
`last_password_change` datetime default null,
`login_error_count` int(11) default null,
`activation_key` varchar(128) default null,
`timezone` varchar(255) default null,
`created_on` datetime NOT NULL,
`updated_on` datetime default null,
`created_by_id` int(11) default null, 
primary key(id)
);



-- -------------------------------------------

--2. TABLE `City`

-- -------------------------------------------
drop table if exists `city`;
create table if not exists `city`(
`id` int(11) not null,
`name` varchar(255) not null unique,
`state` varchar(255) not null,
`state_id` int(11) default '0',
`type_id` int(11) DEFAULT '0',
`created_on` datetime NOT NULL,
`updated_on` datetime default null,
`created_by_id` int(11) default null, 
primary key(id),
KEY `fk_city_create_user` (`created_by_id`),
CONSTRAINT `fk_city_create_user` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`) 
);



-- -------------------------------------------

--3. TABLE `Hotels`

-- -------------------------------------------
drop table if exists `hotels`;
create table if not exists `hotels`(
`id` int(11) not null,
`name` varchar(255) not null unique,
`city` varchar(255) not null,
`landmark` varchar(255) not null,
`star` int(11) default null,
`price_per_room` int(11) not null,
`description` varchar(255) not null,
`facility` varchar(255) not null,
`state_id` int(11) default '0',
`type_id` int(11) DEFAULT '0',
`created_on` datetime NOT NULL,
`updated_on` datetime default null,
`created_by_id` int(11) default null, 
primary key(id),
key `fk_hotels_create_city` (`created_by_id`),
constraint `fk_hotels_create_city` foreign key (`created_by_id`) references `city` (id)
);




-- -------------------------------------------

--4. TABLE `Rooms`

-- -------------------------------------------
drop table if exists `rooms`;
create table if not exists `rooms`(
`id` int(11) not null,
`name` varchar(255) not null unique,
`hotel` varchar(255) not null,
`total_bed` int(11) default null,
`price` int(11) not null,
`other_facility` varchar(255) not null,
`state_id` int(11) default '0',
`type_id` int(11) DEFAULT '0',
`created_on` datetime NOT NULL,
`updated_on` datetime default null,
`created_by_id` int(11) default null, 
primary key(id),
key `fk_rooms_create_hotels` (`created_by_id`),
constraint `fk_rooms_create_hotels` foreign key (`created_by_id`) references `hotels` (id)
);




-- -------------------------------------------
--5. TABLE `Bus`
-- -------------------------------------------
DROP TABLE IF EXISTS `bus`;
CREATE TABLE IF NOT EXISTS `bus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `model` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `bus_type` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `start_city` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `end_city` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `create_time` datetime NOT NULL,
  `update_time` datetime DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_bus_create_city` (`created_by_id`),
  CONSTRAINT `fk_bus_create_city` FOREIGN KEY (`created_by_id`) REFERENCES `city` (`id`)
  );

  
  
  -- -------------------------------------------

--6. TABLE `File`

-- -------------------------------------------
DROP TABLE IF EXISTS `file`;
CREATE TABLE IF NOT EXISTS `file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` int(11) NOT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `model_type` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `model_id` int(11) NOT NULL,
  `type_id` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_file_create_hotels` (`created_by_id`),
  CONSTRAINT `fk_file_create_hotels` FOREIGN KEY (`created_by_id`) REFERENCES `hotels` (`id`)
);
  
  
  
  
-- -------------------------------------------

--7. TABLE `Feedback`

-- -------------------------------------------
DROP TABLE IF EXISTS `feedback`;
CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(256) NOT NULL,
  `last_name` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `message` varchar(256) NOT NULL,
  `state_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `created_by_id` int(11) default null, 
primary key(id),
KEY `fk_feedback_create_user` (`created_by_id`),
CONSTRAINT `fk_feedback_create_user` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`) 
);




-- -------------------------------------------

--8. TABLE `Booking`

-- -------------------------------------------
drop table if exists `booking`;
create table if not exists `booking`(
`id` int(11) not null,
`name` varchar(255) not null,
`email` varchar(255) not null,
`hotel` varchar(255) not null,
`city` varchar(255) not null,
`check_in_date` date not null,
`check_out_date` date not null,
`total_room` int(11) not null,
`booking_date` date not null,
`state_id` int(11) default null,
`created_on` datetime NOT NULL,
`updated_on` datetime default null,
`created_by_id` int(11) default null, 
primary key(id),
KEY `fk_details_create_user` (`created_by_id`),
CONSTRAINT `fk_details_create_user` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`) 
);




-- -------------------------------------------

--9. TABLE `History`

-- -------------------------------------------
drop table if exists `history`;
create table if not exists `history`(
`id` int(11) not null,
`name` varchar(255) not null,
`email` varchar(255) not null,
`hotel` varchar(255) not null,
`city` varchar(255) not null,
`check_in_date` date not null,
`check_out_date` date not null,
`total_room` int(11) not null,
`booking_date` date not null,
`state_id` int(11) default null,
`created_on` datetime NOT NULL,
`updated_on` datetime default null,
`created_by_id` int(11) default null, 
primary key(id),
KEY `fk_details_create_user` (`created_by_id`),
CONSTRAINT `fk_details_create_user` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`) 
);


