<?php
class AcceptanceCest {
	public function _before(AcceptanceTester $I) {
	}
	public function _after(AcceptanceTester $I) {
	}
	public function SignUpFormWorks(AcceptanceTester $I) {
		$I->amOnPage ( '/user/signup' );
		$I->seeElement ( '#form-signup' );
	}
	public function SignUpFormCanBeSubmittedEmpty(AcceptanceTester $I) {
		$I->amOnPage ( '/user/signup' );
		$I->seeElement ( '#form-signup' );
		$I->amGoingTo ( 'submit sign up form without credentials' );
		$I->click ( 'signup-button' );
		$I->expectTo ( 'see validations errors' );
		$req = $I->grabMultiple ( '.required' );
		$count = count ( $req );
		$I->seeNumberOfElements ( '.has-error', $count );
	}
	
	/*
	 * public function SignUpFormUserAdmin(AcceptanceTester $I) {
	 * $I->amOnPage ( '/user/add-admin' );
	 * $I->seeElement ( '#form-signup' );
	 * $I->amGoingTo ( 'submit sign up form for admin user' );
	 * $this->name ='admin';
	 * $this->email='admin@toxsl.in';
	 * $this->password ='admin@123';
	 * $I->fillField ( '#user-full_name', $this->name );
	 * $I->fillField ( '#user-email',$this->email);
	 * $I->fillField ( '#user-password', $this->password);
	 * $I->fillField ( '#user-confirm_password',$this->password);
	 * $I->click ( 'signup-button' );
	 * $I->dontSeeElement('#form-signup');
	 * }
	 */
	public function SignUpFormWithRightCredentials(AcceptanceTester $I) {
		$I->amOnPage ( '/user/add-admin' );
		$I->seeElement ( '#form-signup' );
		$I->amGoingTo ( 'submit sign up form for admin user' );
		$this->name = 'admin';
		$this->email = 'admin@toxsl.in';
		$this->password = 'admin@123';
		LoginHelper::$email = $this->email;
		LoginHelper::$password = $this->password;
		$I->fillField ( '#user-full_name', $this->name );
		$I->fillField ( '#user-email', $this->email );
		$I->fillField ( '#user-password', $this->password );
		$I->fillField ( '#user-confirm_password', $this->password );
		$I->click ( 'signup-button' );
		$I->dontSeeElement ( '#form-signup' );
		$I->see ( 'Admin' );

	}
	public function SignUpFormWithExistingEmail(AcceptanceTester $I) {
		$I->amOnPage ( '/user/signup' );
		$I->seeElement ( '#form-signup' );
		$var = 'admin@toxsl.in';
		$I->fillField ( '#user-full_name', 'admin' );
		$I->fillField ( '#user-email', $var );
		$I->fillField ( '#user-password', 'admin@123' );
		$I->fillField ( '#user-confirm_password', 'admin@123' );
		$I->click ( 'signup-button' );
		$I->seeElement ( '.has-error' );
	}
	public function SignUpFormWithWrongCredentials(AcceptanceTester $I) {
		$I->amOnPage ( '/user/signup' );
		$I->seeElement ( '#form-signup' );
		$I->amGoingTo ( 'submit sign up form with wrong credentials' );
		$I->fillField ( '#user-full_name', '2342@$@$@#$' );
		$I->fillField ( '#user-email', 'abc' );
		$I->click ( 'signup-button' );
		$I->expectTo ( 'see validations errors' );
		$I->seeElement ( '.has-error' );
	}
	public function LoginFormWorks(AcceptanceTester $I) {
		$I->amOnPage ( '/user/login' );
		$I->seeElement ( '#login-form' );
	}
	public function LogInFormCanBeSubmittedEmpty(AcceptanceTester $I) {
		$I->amOnPage ( '/user/login' );
		$I->seeElement ( '#login-form' );
		$I->amGoingTo ( 'submit login form without credentials' );
		$I->click ( 'login-button' );
		$I->expectTo ( 'see validations errors' );
		$req = $I->grabMultiple ( '.required' );
		$count = count ( $req );
		$I->seeNumberOfElements ( '.has-error', $count );
	}
	public function LoginFormWithRightCredentials(AcceptanceTester $I) {
		$I->amOnPage ( '/user/login' );
		$I->seeElement ( '#login-form' );
		$I->amGoingTo ( 'submit login form with right credentials' );
		$this->email = 'admin@toxsl.in';
		$this->password = 'admin@123';
		LoginHelper::$email = $this->email;
		LoginHelper::$password = $this->password;
		$I->fillField ( '#loginform-username',LoginHelper::$email);
		$I->fillField ( '#loginform-password', LoginHelper::$password);
		$I->click ( 'login-button' );
		// $I->seeElement ( 'span.brand-name' );
	}
	public function LoginFormWithWrongEmailFormat(AcceptanceTester $I) {
		$I->amOnPage ( '/user/login' );
		$I->seeElement ( '#login-form' );
		$I->amGoingTo ( 'submit login form with wrong email' );
		$I->fillField ( '#loginform-username', 'abc' );
		$I->fillField ( '#loginform-password', 'wrong' );
		$I->click ( 'login-button' );
		$I->expectTo ( 'see validations errors' );
		$I->seeElement ( '.has-error' );
	}
	public function LoginFormWithWrongCredentials(AcceptanceTester $I) {
		$I->amOnPage ( '/user/login' );
		$I->seeElement ( '#login-form' );
		$I->amGoingTo ( 'submit login form with wrong credentials' );
		$I->fillField ( '#loginform-username', 'abc@gmail.com' );
		$I->fillField ( '#loginform-password', 'wrong' );
		$I->click ( 'login-button' );
		$I->expectTo ( 'see validations errors' );
		$I->seeElement ( '.has-error' );
	}
	public function PasswordRecoverFormWorks(AcceptanceTester $I) {
		$I->amOnPage ( '/user/login' );
		$I->seeElement ( '.forgot.pull-right' );
		$I->click ( 'Forgot Password?' );
		$I->seeElement ( '#request-password-reset-form' );
	}
	public function PasswordRecoverFormWithoutEmail(AcceptanceTester $I) {
		$I->amOnPage ( '/user/recover' );
		$I->seeElement ( '#request-password-reset-form' );
		$I->amGoingTo ( 'submit email field without email' );
		$I->click ( 'send-button' );
		$I->expectTo ( 'see validations errors' );
		$I->seeElement ( '.required' );
	}
}