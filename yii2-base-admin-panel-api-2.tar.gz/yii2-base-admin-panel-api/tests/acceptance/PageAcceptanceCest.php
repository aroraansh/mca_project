<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author	 : Shiv Charan Panjeta < shiv@toxsl.com >
 */
class PageAcceptanceCest 

{
	public $id = null;
	public $var;
	public function _before(AcceptanceTester $I) 
	{
			LoginHelper::login($I);
	}
	public function _after(AcceptanceTester $I) 
	{
	
	
	}

	public function IndexWorks(AcceptanceTester $I) 
	{
			$I->amOnPage ( '/page/index' );
			$I->seeElement ( '.grid-view' );
	}
	public function AddFormCanBeSubmittedEmpty(AcceptanceTester $I) 
	{
			$I->amOnPage ( '/page/add' );
			$I->seeElement ( '#page-form' );
			$I->amGoingTo ( 'add form without credentials' );
			$I->click ( 'page-button' );
			$I->expectTo ( 'see validations errors' );
			$req = $I->grabMultiple ( '.required' );
			$count = count ( $req )-1;
			$I->seeNumberOfElements ( '.has-error', $count );
	}
	public function AddWorksWithData(AcceptanceTester $I) 
	{
			$I->amOnPage ( '/page/add' );
			$I->seeElement ( '#page-form' );
			$I->amGoingTo ( 'add form with right data' );
			
		$this->name=LoginHelper::randomName();
		$this->var=$this->name;
		$I->fillField ('#page-title',$this->name);
		$I->fillField ('#page-description',$this->name);
			$I->selectOption ('#page-state_id','0');
			$I->selectOption ('#page-type_id','0');
			
			$I->click ( 'page-button' );
			$I->dontseeElement ( '#page-form' );
		
			$this->id = $I->grabFromCurrentUrl ( '/page\/(\d+)$/' );
			echo $this->id;
	}
	
 	public function ViewWorks(AcceptanceTester $I) 
	{
			$I->amOnPage ( '/page/' . $this->id );
			$I->amGoingTo ( 'View page details' );
			$I->see ( $this->var);
	
	} 
	public function UpdateWorks(AcceptanceTester $I) 
{
			$I->amOnPage ( '/page/update/'. $this->id  );
			$I->seeElement ( '#page-form' );
			$I->amGoingTo ( 'add form with right data' );
			
			$this->name=LoginHelper::randomName();
			$I->fillField ('#page-title',$this->name);
			$I->fillField ('#page-description',$this->name);
			$I->selectOption ('#page-state_id','0');
			$I->selectOption ('#page-type_id','0');
			
			$I->click ( 'page-button' );
			$I->dontseeElement ( '#page-form' );
			
			
		
	}
	public function DeleteWorks(AcceptanceTester $I) 
	{
		$I->sendAjaxPostRequest ( '/page/delete/' . $this->id );
			$I->expectTo ( 'delete page works' );
			$I->amOnPage ( '/page/' . $this->id );
	}
	
		
	
}
