<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author	 : Shiv Charan Panjeta < shiv@toxsl.com >
 */
class SettingAcceptanceCest 

{
	public $id = null;	
	public function _before(AcceptanceTester $I) 
	{
			LoginHelper::login($I);
	}
	public function _after(AcceptanceTester $I) 
	{
	
	
	}

	public function IndexWorks(AcceptanceTester $I) 
	{
			$I->amOnPage ( '/setting/index' );
			
	}
	public function AddFormCanBeSubmittedEmpty(AcceptanceTester $I) 
	{
			$I->amOnPage ( '/setting/add' );
			$I->seeElement ( '#setting-form' );
			$I->amGoingTo ( 'add form without credentials' );
			$I->click ( 'setting-button' );
			$I->expectTo ( 'see validations errors' );
			$req = $I->grabMultiple ( '.required' );
			$count = count ( $req );
			$I->seeNumberOfElements ( '.has-error', $count );
	}
	public function AddWorksWithData(AcceptanceTester $I) 
	{
			$I->amOnPage ( '/setting/add' );
			$I->seeElement ( '#setting-form' );
			$I->amGoingTo ( 'add form with right data' );
			$this->name=LoginHelper::randomName();
			$this->var=$this->name;
			$I->fillField ('#setting-key',$this->name);
			$I->selectOption ('#setting-type_id','0');
			$I->fillField ('#setting-value',$this->name);
			$I->fillField ('#setting-default','0');
			/*$I->fillField ('#setting-created_by_id','1'); */
			$I->click ( 'setting-button' );
			$I->dontseeElement ( '#setting-form' );
			$this->id = $I->grabFromCurrentUrl ( '/setting\/(\d+)$/' );
			echo $this->id;
	}
	
/* 	public function ViewWorks(AcceptanceTester $I) 
	{
			$I->amOnPage ( '/setting/' . $this->id );
			$I->amGoingTo ( 'View setting details' );
			$I->see ( $this->var);
	
	} */
	public function UpdateWorks(AcceptanceTester $I) 
{
			$I->amOnPage ( '/setting/update/'. $this->id  );
			$I->seeElement ( '#setting-form' );
			$I->amGoingTo ( 'add form with right data' );
			$this->name=LoginHelper::randomName();
			$this->var=$this->name;
			$I->fillField ('#setting-key',$this->name);
			$I->selectOption ('#setting-type_id','0');
			$I->fillField ('#setting-value',$this->name);
			$I->fillField ('#setting-default','0');
			/*$I->fillField ('#setting-created_by_id','1'); */
			$I->click ( 'setting-button' );
			$I->dontseeElement ( '#setting-form' );
	}
	public function DeleteWorks(AcceptanceTester $I) 
	{
		$I->sendAjaxPostRequest ( '/setting/delete/' . $this->id );
			$I->expectTo ( 'delete setting works' );
			$I->amOnPage ( '/setting/' . $this->id );
	}
	
		

	
}
