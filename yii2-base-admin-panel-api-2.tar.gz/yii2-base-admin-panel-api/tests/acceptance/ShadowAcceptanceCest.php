<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author  : Shiv Charan Panjeta < shiv@toxsl.com >
 */
class ShadowAcceptanceCest {
	public $id = null;
	public function _before(AcceptanceTester $I) {
		LoginHelper::login ( $I );
	}
	public function _after(AcceptanceTester $I) {
	}
	public function Index(AcceptanceTester $I) {
		$I->amOnPage ( '/shadow/index' );
		$I->expectTo ( 'See icon in page head' );
	//	$I->seeElement ( '.grid-view' );
	}



}

