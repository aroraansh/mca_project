<?php
class SiteAcceptanceCest {
	public function _before(AcceptanceTester $I) {
	}
	public function _after(AcceptanceTester $I) {
	}
	
	// tests
	public function Homepage(AcceptanceTester $I) {
		$I->wantTo ( 'frontpage works' );
		$I->amOnPage ( '/' );
		$I->see ( 'Admin Project', 'h1' );
	}
	public function AboutWorks(AcceptanceTester $I) {
		$I->amOnPage ( '/about' );
		$I->wantTo ( ' About page works' );
		$I->see ( 'AboutUs', 'h1' );
	}
	public function contactPageWorks(AcceptanceTester $I) {
		$I->amOnPage ( '/contactus' );
		$I->wantTo ( 'Contact page works' );
		$I->see ( 'Contact Form', 'h3' );
	}
	public function contactFormCanBeSubmittedEmpty(AcceptanceTester $I) {
		$I->amOnPage ( '/contact' );
		$I->seeElement ( '#contact-form' );
		$I->amGoingTo ( 'submit contact form without credentials' );
		$I->click ( 'submit-button' );
		$I->expectTo ( 'see validations errors' );
		$req = $I->grabMultiple ( '.required' );
		$count = count ( $req );
		$I->seeNumberOfElements ( '.has-error', $count );
	}
	public function contactFormCanBeSubmitted(AcceptanceTester $I) {
		$I->amOnPage ( '/contact' );
		$I->seeElement ( '#contact-form' );
		$I->amGoingTo ( 'submit contact form with correct data' );
		$this->name = LoginHelper::randomName ();
		$this->email = LoginHelper::randomMail ();
		$I->fillField ( '#contactform-name',$this->name );
		$I->fillField ( '#contactform-email',$this->email );
		$I->fillField ( '#contactform-subject',$this->name );
		$I->fillField ( '#contactform-body',$this->name);
		$I->click ( 'submit-button' );
		$I->dontSeeElement ( '#contact-form' );
		//$I->see ( 'Thank you' );
	}
}

