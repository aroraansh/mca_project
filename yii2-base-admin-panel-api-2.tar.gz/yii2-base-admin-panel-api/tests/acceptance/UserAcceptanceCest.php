<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author  : Shiv Charan Panjeta < shiv@toxsl.com >
 */


class UserAcceptanceCest {
	public $id = null;
	public function _before(AcceptanceTester $I) {
		LoginHelper::login($I);
	}
	public function _after(AcceptanceTester $I) {
	}
	public function Index(AcceptanceTester $I) {
		$I->amOnPage ( '/user' );
		$I->expectTo ( 'See icon in page head' );
		$I->seeElement ( '.grid-view' );
	}
	public function Add(AcceptanceTester $I) {
		$I->amOnPage ( '/user/add' );
		$I->amGoingTo ( 'Add User Form With correct data' );
		$I->seeElement ( '#user-form' );
		$this->email = LoginHelper::randomMail ();
		$this->name = LoginHelper::randomName ();
		$I->fillField ( '#user-full_name', $this->name );
		$I->fillField ( '#user-email', $this->email );
		//$I->fillField ( '#user-role-id', 0 );
		$I->click ( 'user-form-submit' );
		$I->dontseeElement ( '#user-form' );
		$I->see ( $this->name, 'h1' );
		$this->id = $I->grabFromCurrentUrl ( '/user\/(\d+)$/' );
		echo $this->id;
	}
	public function View(AcceptanceTester $I) {
		$I->amOnPage ( '/user/' . $this->id );
		$I->amGoingTo ( 'View User details' );
		$I->see ( $this->name, 'h1' );
	}
	public function Update(AcceptanceTester $I) {
		$I->amOnPage ( '/user/update/' . $this->id );
		$I->amGoingTo ( 'Edit User details' );
		$I->seeElement ( '#user-form' );
		$this->email = LoginHelper::randomMail ();
		$this->name = LoginHelper::randomName ();
		$I->fillField ( '#user-full_name', $this->name );
		$I->fillField ( '#user-email', $this->email );
		$I->click ( 'user-form-submit' );
		$I->dontseeElement ( '#user-form' );
		$I->seeElement ( '.table.table-bordered' );
	}
	public function Delete(AcceptanceTester $I) {
		$I->sendAjaxPostRequest ( '/user/delete/' . $this->id );
		$I->amGoingTo ( 'delete User works' );
		$I->amOnPage ( '/user/' . $this->id );
		$I->dontsee ( $this->name, 'h1' );
	}
}