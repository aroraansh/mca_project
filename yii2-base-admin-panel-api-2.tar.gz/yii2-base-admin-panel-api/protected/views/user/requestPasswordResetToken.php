<?php

/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author	 : Shiv Charan Panjeta < shiv@toxsl.com >
 */
use app\components\TActiveForm;
use yii\helpers\Html;
use yii\helpers\Inflector;
/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \frontend\models\PasswordResetRequestForm */

$this->params ['breadcrumbs'] [] = [ 
		'label' => 'Users',
		'url' => [ 
				'user/index' 
		] 
];

$this->params ['breadcrumbs'] [] = Inflector::humanize ( Yii::$app->controller->action->id );

?>
<div class="site-resetPassword">
	<div class="container log-row">
		<section class="content">
			<div class="row">
				<div class="col-md-4 col-md-offset-4">
					<div class="box box-primary">

						<p> <?= \Yii::t("app", "Please fill out your email. A link to reset password will be sent there.") ?></p>

						<div class="row">
							<div class="col-lg-12">
            <?php
												
												$form = TActiveForm::begin ( [ 
														'id' => 'request-password-reset-form',
														'enableClientValidation' => true,
														'enableAjaxValidation' => false 
												] );
												?>
            
                <?= $form->field($model, 'email') ?>
                <div class="form-group">
                    <?= Html::submitButton('Send', ['class' => 'btn btn-success','name' => 'send-button']) ?>
                </div>
           <?php TActiveForm::end(); ?>
        </div>
						</div>
					</div>
				</div>
			</div>


		</section>
	</div>
</div>
</div>
