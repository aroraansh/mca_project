<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author	 : Shiv Charan Panjeta < shiv@toxsl.com >
 */
/* @var $this yii\web\View */

/*
 * $this->title = 'About';
 * $this->params ['breadcrumbs'] [] = $this->title;
 */
?>
<div class="site-about">
	<h1>AboutUs</h1>

	

	<code><?= __FILE__ ?></code>
</div>
