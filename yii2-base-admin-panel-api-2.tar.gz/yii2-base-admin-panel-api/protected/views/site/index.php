<?php

/**
 *
 * @copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 * @author : Shiv Charan Panjeta < shiv@toxsl.com >
 */
/* @var $this yii\web\View */
$this->title = Yii::$app->name;

?>
<style>
</style>
<div class="background-image main_wrapper">
	<div class=" banner-section">
		<div class="text-center">
			<h1><?=Yii::$app->name?></h1>

			<br>
		</div>
	</div>
</div>


