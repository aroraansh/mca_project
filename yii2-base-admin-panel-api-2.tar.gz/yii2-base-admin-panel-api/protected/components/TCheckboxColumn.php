<?php
namespace app\components;

use yii\grid\CheckboxColumn;

class TCheckboxColumn extends CheckboxColumn
{
    
    public $userData = null;
    
 
}