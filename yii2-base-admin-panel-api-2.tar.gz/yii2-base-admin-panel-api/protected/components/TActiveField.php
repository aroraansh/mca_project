<?php

namespace app\components;

use yii\bootstrap\ActiveField;

class TActiveField extends ActiveField {
}