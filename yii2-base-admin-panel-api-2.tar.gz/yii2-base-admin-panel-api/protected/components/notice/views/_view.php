<?php
?>

<li><div class="items">

		<div class="menu-text">
		
			<?php echo $model->linkify()?>
		</div>

	</div></li>
<div class="clearfix"></div>





