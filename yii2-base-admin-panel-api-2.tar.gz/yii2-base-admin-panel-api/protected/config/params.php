<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author	 : Shiv Charan Panjeta < shiv@toxsl.com >
 */
return [
    'adminEmail' => 'admin@toxsl.in',
    'company' => 'ToXSL Technologies',
    'companyUrl' => 'https://www.toxsl.com',
    'user.passwordResetTokenExpire' => 60
];
