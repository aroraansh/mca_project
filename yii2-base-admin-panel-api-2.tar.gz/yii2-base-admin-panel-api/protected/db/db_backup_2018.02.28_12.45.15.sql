-- -------------------------------------------
SET AUTOCOMMIT=0;
START TRANSACTION;
SET SQL_QUOTE_SHOW_CREATE = 1;
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
-- -------------------------------------------

-- -------------------------------------------

-- START BACKUP

-- -------------------------------------------

-- -------------------------------------------

-- TABLE `tbl_comment`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_comment`;
CREATE TABLE IF NOT EXISTS `tbl_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` text COLLATE utf8_unicode_ci,
  `model_type` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `model_id` int(11) NOT NULL,
  `state_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_comment_created_by` (`created_by_id`),
  CONSTRAINT `fk_comment_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_email_queue`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_email_queue`;
CREATE TABLE IF NOT EXISTS `tbl_email_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_email` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `to_email` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci,
  `subject` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_published` datetime DEFAULT NULL,
  `last_attempt` datetime DEFAULT NULL,
  `date_sent` datetime DEFAULT NULL,
  `attempts` int(11) DEFAULT NULL,
  `state_id` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `model_type` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_account_id` int(11) DEFAULT NULL,
  `message_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_file`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_file`;
CREATE TABLE IF NOT EXISTS `tbl_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `file` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `size` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `extension` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `model_id` int(11) NOT NULL,
  `model_type` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_file_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_file_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_log`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_log`;
CREATE TABLE IF NOT EXISTS `tbl_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `error` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `api` text COLLATE utf8_unicode_ci,
  `description` text COLLATE utf8_unicode_ci,
  `state_id` int(11) DEFAULT '1',
  `link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_login_history`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_login_history`;
CREATE TABLE IF NOT EXISTS `tbl_login_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `failer_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_notice`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_notice`;
CREATE TABLE IF NOT EXISTS `tbl_notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `model_type` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL DEFAULT '0',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_notice_created_by` (`created_by_id`),
  CONSTRAINT `fk_notice_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_notification`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_notification`;
CREATE TABLE IF NOT EXISTS `tbl_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `model_id` int(11) NOT NULL,
  `model_type` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `to_user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_notification_to_user_id` (`to_user_id`),
  CONSTRAINT `fk_notification_to_user_id` FOREIGN KEY (`to_user_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_page`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_page`;
CREATE TABLE IF NOT EXISTS `tbl_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_page_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_page_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_setting`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_setting`;
CREATE TABLE IF NOT EXISTS `tbl_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci,
  `type_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `state_id` int(11) DEFAULT '0',
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_user`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` int(11) DEFAULT '0',
  `about_me` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zipcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_verified` tinyint(1) DEFAULT '0',
  `profile_file` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tos` int(11) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `type_id` int(11) DEFAULT '0',
  `last_visit_time` datetime DEFAULT NULL,
  `last_action_time` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `login_error_count` int(11) DEFAULT NULL,
  `activation_key` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `timezone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




INSERT INTO `tbl_email_queue` (`id`,`from_email`,`to_email`,`message`,`subject`,`date_published`,`last_attempt`,`date_sent`,`attempts`,`state_id`,`model_id`,`model_type`,`email_account_id`,`message_id`) VALUES
("1","shubham@toxsl.in","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">Admin Project</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td colspan=\"2\" style=\"padding: 30px 0;\">
		<p
			style=\"color: #1d2227; line-height: 28px; font-size: 25px; margin: 12px 10px 16px 10px; font-weight: 400;\">Welcome
			to jiPanel</p>
		<p style=\"margin: 0 10px 10px 10px; padding: 0; font-size: 14px;\">
			Thanks for signing up. To send your first ToXSL Technologies, please verify<br>
			your email address by clicking the button below.
		</p>
		<p>
			<a
				style=\"display: inline-block; text-decoration: none; padding: 11px 20px; background-color: #6dbd63; border: 1px solid #6dbd63; border-radius: 3px; color: #FFF; font-weight: bold;\"
				href=\"http://localhost/yii2-base-admin-panel-api/user/confirm-email?id=gA5L1uDZuXt6GuC8S9KB9zIKqdEgE3Sk_1519651436\" target=\"_blank\">Activate your account and
				log in</a>
		</p>
		<p>
			<font size=\"2\" color=\"#333\"> If above link isn‘t working, please copy
				and paste it directly in you browser‘s URL field to get started.<br />
				<br />
	                          
	                              http://localhost/yii2-base-admin-panel-api/user/confirm-email?id=gA5L1uDZuXt6GuC8S9KB9zIKqdEgE3Sk_1519651436								</font>
		</p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>Admin Project Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; Admin Project</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","New User Registerd Successfully","","","2018-02-26 18:53:56","","1","","","","90fccc00da101ffc3794810fb923fdfc@localhost");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_log` (`id`,`error`,`api`,`description`,`state_id`,`link`,`type_id`,`created_on`) VALUES
("1","You are not allowed to perform this action.","","#0 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /home/local/TOXSL/shubham.kamboj/htdocs/yii2-base-admin-panel-api/protected/components/TController.php(241): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘‘, Array)
#9 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘dashboard‘, Array)
#10 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /home/local/TOXSL/shubham.kamboj/htdocs/yii2-base-admin-panel-api/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /yii2-base-admin-panel-api/dashboard","0","2018-02-26 18:04:38"),
("2","You are not allowed to perform this action.","","#0 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /home/local/TOXSL/shubham.kamboj/htdocs/yii2-base-admin-panel-api/protected/components/TController.php(241): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘‘, Array)
#9 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘dashboard‘, Array)
#10 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /home/local/TOXSL/shubham.kamboj/htdocs/yii2-base-admin-panel-api/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /yii2-base-admin-panel-api/dashboard","0","2018-02-26 18:53:57"),
("3","You are not allowed to perform this action.","","#0 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /home/local/TOXSL/shubham.kamboj/htdocs/yii2-base-admin-panel-api/protected/components/TController.php(241): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘‘, Array)
#9 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘dashboard‘, Array)
#10 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /home/local/TOXSL/shubham.kamboj/htdocs/yii2-base-admin-panel-api/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /yii2-base-admin-panel-api/dashboard","0","2018-02-26 18:54:23"),
("4","You are not allowed to perform this action.","","#0 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /home/local/TOXSL/shubham.kamboj/htdocs/yii2-base-admin-panel-api/protected/components/TController.php(241): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘index‘, Array)
#9 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘dashboard/index‘, Array)
#10 /home/local/TOXSL/shubham.kamboj/htdocs/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /home/local/TOXSL/shubham.kamboj/htdocs/yii2-base-admin-panel-api/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /yii2-base-admin-panel-api/dashboard/index","0","2018-02-26 18:54:25");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_login_history` (`id`,`user_id`,`user_ip`,`user_agent`,`failer_reason`,`state_id`,`type_id`,`code`,`created_on`) VALUES
("4","1","127.0.0.1","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:58.0) Gecko/20100101 Firefox/58.0","","1","0","http://localhost/yii2-base-admin-panel-api/user/login","2018-02-27 17:32:11");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_setting` (`id`,`key`,`title`,`value`,`type_id`,`state_id`,`created_by_id`) VALUES
("1","appConfig","App Configration","{\"companyUrl\":{\"type\":0,\"value\":\"https://www.toxsl.com\",\"required\":true},\"company\":{\"type\":0,\"value\":\"ToXSL Technologies\",\"required\":true},\"companyEmail\":{\"type\":0,\"value\":\"admin@toxsl.in\",\"required\":true},\"companyContactEmail\":{\"type\":0,\"value\":\"admin@toxsl.in\",\"required\":false},\"companyContactNo\":{\"type\":0,\"value\":\"9569127788\",\"required\":false},\"companyAddress\":{\"type\":0,\"value\":\"C-127, 4th floor, Phase 8, Industrial Area, Sector 72, Mohali, Punjab\",\"required\":false},\"loginCount\":{\"type\":2,\"value\":2,\"required\":false}}","0","0","1"),
("2","smtp","SMTP Configration","{\"host\":{\"type\":0,\"value\":\"\",\"required\":true},\"username\":{\"type\":0,\"value\":\"\",\"required\":true},\"password\":{\"type\":0,\"value\":\"\",\"required\":true},\"port\":{\"type\":0,\"value\":\"\",\"required\":true},\"encryption\":{\"type\":0,\"value\":\"\",\"required\":false}}","0","0","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_user` (`id`,`full_name`,`email`,`password`,`date_of_birth`,`gender`,`about_me`,`contact_no`,`address`,`latitude`,`longitude`,`city`,`country`,`zipcode`,`language`,`email_verified`,`profile_file`,`tos`,`role_id`,`state_id`,`type_id`,`last_visit_time`,`last_action_time`,`last_password_change`,`login_error_count`,`activation_key`,`timezone`,`created_on`,`updated_on`,`created_by_id`) VALUES
("1","VAibhav Jain","admin@toxsl.in","$2y$13$b5zXZGx0V41Ja3x20po9A.1vjGRKiK9HrCUBZi.eKkLf7/0w2blI6","","0","","","","","","","","","","0","","","0","1","0","2018-02-28 10:03:16","","","","eCnpr8sHtHaXWV5NeLNDNU1fo-mDzscA_1519648478","","2018-02-26 18:04:38","2018-02-28 10:03:16",""),
("2","shubham","shubham@toxsl.in","$2y$13$MfinKaLSsYDy4QiLZ1l9ze8dTWCyiGUJ35wRwgyM5AGETG8p3KevO","","0","","","","","","","","","","0","","","0","1","0","2018-02-27 17:09:49","","","","gA5L1uDZuXt6GuC8S9KB9zIKqdEgE3Sk_1519651436","","2018-02-26 18:53:55","2018-02-27 17:09:49","");

 -- -------AutobackUpStarttoxsl------ -- -------------------------------------------
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
COMMIT;
 -- -------AutobackUpStarttoxsl------ -- -------------------------------------------

-- -------------------------------------------

-- END BACKUP

-- -------------------------------------------
