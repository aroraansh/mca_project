<?php
namespace app\modules\diagram\controllers;

use app\components\TController;
use app\modules\diagram\models\search\Diagram;

// use app\modules\diagram\models\search\diagram;
/**
 * Default controller for the `diagram` module
 */
class DefaultController extends TController
{

    /**
     * Renders the index view for the module
     * 
     * @return string
     */
//     public function actionIndex()
//     {
//         //return $this->redirect('index');
//         $searchModel = new Diagram() ;
//         $dataProvider = $searchModel->search(\Yii::$app->request->queryParams);
//         $this->updateMenuItems();
//         return $this->render('index', [
//             'searchModel' => $searchModel,
//             'dataProvider' => $dataProvider
//         ]);
//     }
    
//     public function actionView($id)
//     {
//         die('v');
//         $model = $this->findModel($id);
//         $this->updateMenuItems($model);
//         return $this->render('view', ['model' => $model]);
        
//     }
}