<?php
use app\components\TActiveForm;
use yii\helpers\Html;
/* @var $this yii\web\View */
/* @var $model app\models\Diagram */

/* $this->title = $model->label() .' : ' . $model->title; */
$this->params['breadcrumbs'][] = [
    'label' => Yii::t('app', 'Diagrams'),
    'url' => [
        'index'
    ]
];
$this->params['breadcrumbs'][] = (string) $model;
?>

<div class="wrapper">
	<div class=" panel ">
		<div class="diagram-view panel-body">
			<?php echo  \app\components\PageHeader::widget(['model'=>$model]); ?>
		</div>
	</div>
	<div class=" panel ">
		<div class=" panel-body ">
        	<?php
        
        echo \app\components\TDetailView::widget([
            'id' => 'diagram-detail-view',
            'model' => $model,
            'options' => [
                'class' => 'table table-bordered'
            ],
            'attributes' => [
                'id',
                'title',
                /*'description:html',*/
                'created_on:datetime',
                'updated_on:datetime',
                [
                    'attribute' => 'created_by_id',
                    'format' => 'raw',
                    'value' => $model->getRelatedDataLink('created_by_id')
                ]
            ]
        ])?>
		</div>
	</div>
	<div class="panel-body">

    <?php
    $form = TActiveForm::begin([
        'action' => [
            'diagram/run'
        ],
        'layout' => 'horizontal',
        'id' => 'diagram-form'
    
    ]);
    ?>
	
		 <?php echo $form->field($model, 'description')->textarea(['rows' => '10']) ?>
	 	

	  <div class="form-group">
			<div
				class="col-md-6 col-md-offset-3 bottom-admin-button btn-space-bottom text-right">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Save') : Yii::t('app', 'Run'), ['id'=> 'diagram-form-submit','class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>
		</div>
    <?php TActiveForm::end(); ?>

</div>


</div>
