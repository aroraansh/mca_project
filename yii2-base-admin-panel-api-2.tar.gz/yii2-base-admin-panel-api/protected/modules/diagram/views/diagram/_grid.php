<?php
use app\components\TGridView;
use app\models\User;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\Pjax;
/**
 *
 * @var yii\web\View $this
 * @var yii\data\ActiveDataProvider $dataProvider
 * @var app\models\search\Diagram $searchModel
 */

?>
<?php if (User::isAdmin()) echo Html::a('','#',['class'=>'multiple-delete glyphicon glyphicon-trash','id'=>"bulk_delete_diagram-grid"])?>
<?php Pjax::begin(['id'=>'diagram-pjax-grid']); ?>
    <?php
   
echo TGridView::widget([
        'id' => 'diagram-grid-view',
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'tableOptions' => [
            'class' => 'table table-bordered'
        ],
        'columns' => [
            [
                'name' => 'check',
                'class' => 'yii\grid\CheckboxColumn',
                'visible' => User::isAdmin()
            ],
            ['class' => 'yii\grid\SerialColumn','header'=>'<a>S.No.<a/>'],
            'id',
            'title',
            // 'description:html',
            'created_on:datetime',
            /* 'updated_on:datetime',*/
            [
                'attribute' => 'created_by_id',
                'format' => 'raw',
                'value' => function ($data) {
                    return $data->getRelatedDataLink('created_by_id');
                }
            ],
            
            [
                'class' => 'app\components\TActionColumn',
                'header' => '<a>Actions</a>',
                'template' => '{view}{update}{delete}',
                'buttons' => [
                    'view' => function ($url, $model) {
                    if ($model->created_by_id == \Yii::$app->user->id || User::isAdmin())
                        return Html::a('<i class="glyphicon glyphicon-eye-open"></i>', Url::toRoute([
                            'diagram/view',
                            'id' => $model->id
                        ]), [
                            'title' => Yii::t('app', 'view'),
                            'class' => 'btn btn-success btn-green' 
//                             'data-method' => 'post',
//                             'data-confirm' => 'Do You really Want to Delete this Item? '
                        ]);
                    },
                    'update' => function ($url, $model) {
                    if ($model->created_by_id == \Yii::$app->user->id || User::isAdmin())
                        return Html::a('<i class="glyphicon glyphicon-pencil"></i>', Url::toRoute([
                            'diagram/update',
                            'id' => $model->id
                        ]), [
                            'title' => Yii::t('app', 'update'),
                            'class' => 'btn btn-info btn-blue-info'
                            //                             'data-method' => 'post',
                    //                             'data-confirm' => 'Do You really Want to Delete this Item? '
                        ]);
                    },
                    'delete' => function ($url, $model) {
                    if ($model->created_by_id == \Yii::$app->user->id || User::isAdmin())
                        return Html::a('<i class="glyphicon glyphicon-trash"></i>', Url::toRoute([
                            'diagram/delete',
                            'id' => $model->id
                        ]), [
                            'title' => Yii::t('app', 'delete'),
                            'class' => 'btn btn-danger btn-red',
                                                         'data-method' => 'post',
                                                         'data-confirm' => 'Do You really Want to Delete this Item? '
                        ]);
                    }
                    ]
            ]
        ]
    ]);
    ?>
<?php Pjax::end(); ?>
<script> 
$('#bulk_delete_diagram-grid').click(function(e) {
	e.preventDefault();
	 var keys = $('#diagram-grid-view').yiiGridView('getSelectedRows');

	 if ( keys != '' ) {
		var ok = confirm("Do you really want to delete these items?");

		if( ok ) {
			$.ajax({
				url  : '<?php echo Url::toRoute(['diagram/mass','action'=>'delete','model'=>get_class($searchModel)])?>', 
				type : "POST",
				data : {
					ids : keys,
				},
				success : function( response ) {
					if ( response.status == "OK" ) {
						 $.pjax.reload({container: '#diagram-pjax-grid'});
					}
				}
		     });
		}
	 } else {
		alert('Please select items to delete');
	 }
});

</script>

