<?php

/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author	 : Shiv Charan Panjeta < shiv@toxsl.com >
 */
namespace app\controllers;

use app\components\TController;
use Imagine\Image\ManipulatorInterface;
use yii\filters\AccessControl;
use yii\imagine\Image;
use yii\web\NotFoundHttpException;

class ImageController extends TController
{

    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'actions' => [
                            'crop',
                            'files',
                            'thumbnail'
                        ],
                        'allow' => true,
                        'roles' => [
                            '*',
                            '?',
                            '@'
                        ]
                    ]
                ]
            ]
        ];
    }

    public function actionFiles($file)
    {
        $image_path = UPLOAD_PATH . 'files/' . $file;
        if (! file_exists($image_path))
            throw new NotFoundHttpException(\Yii::t('app', "File not found"));
        return \yii::$app->response->sendFile($image_path, $file);
    }

    public function actionCrop($filename, $width, $height, $crop = true, $start = [0, 0])
    {
        $file = UPLOAD_PATH . $filename;
        
        if (file_exists($file) && ! is_dir($file)) {
            if ($crop == true) {
                return Image::crop($file, $width, $height, $start);
            } else {
                \Yii::$app->response->sendFile($file);
            }
        }
    }

    /*
     * const THUMBNAIL_INSET = 'inset';
     * const THUMBNAIL_OUTBOUND = 'outbound';
     *
     */
    public function actionThumbnail($filename, $width = 150, $height = 150, $mode = ManipulatorInterface::THUMBNAIL_OUTBOUND)
    {
        $file = UPLOAD_PATH . $filename;
        if (file_exists($file) && ! is_dir($file)) {
            return Image::thumbnail($file, $width, $height, $mode);
        }
    }
}
