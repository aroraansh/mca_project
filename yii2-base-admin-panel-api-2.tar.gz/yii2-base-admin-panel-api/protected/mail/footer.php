</td>
<tr>
	<td align="left" style="padding-top: 8px; padding-bottom: 3px;">
		<p
			style="font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;"></p>
		<p
			style="font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666">
			Thanks & Regards,<br><?php echo \yii::$app->name?> Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style="border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;"
			align="left" bgcolor="#00A65A"><h3
				style="font-size: 15px; font-weight: 400; color: #fff; margin: 0;">Copyright
									&copy; <?php echo \yii::$app->name?></h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>