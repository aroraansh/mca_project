<?php
?>
<?php

?>
<?= $this->render ( 'header.php' );?>
<tr>
	<td align="left">
		<p
			style="font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;">
			<?php echo $content;?> 
		</p>
	</td>
</tr>
<?= $this->render ( 'footer.php' );?>