﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","oc",{title:"Proprietats de l'espaci reservat",toolbar:"Espaci reservat",name:"Nom de l'espaci reservat",invalidName:"L'espaci reservat pòt pas èsser void ni conténer un d'aquestes caractèrs : [, ], \x3c, \x3e",pathName:"espaci reservat"});