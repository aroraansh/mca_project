<?php
?>
<div class="offers-1">
	<div class="container">
		<div class="col-md-4 wow fadeInLeft animated" data-wow-delay=".5s">
			<div class="offers-1-left">
				<i class="fa fa-usd"></i>
				<p>Get upto Rs.100 off on all Bus bookings</p>
				<h3>Get Rs.100 on Hotels + PayUMoney</h3>
				<h6>Valid till 29-Mar-2016</h6>
				<a href="#" class="off" data-toggle="modal" data-target="#myModal2">View Offer</a>
			</div>
		</div>
		<div class="col-md-4 wow fadeInUp animated" data-wow-delay=".5s">
			<div class="offers-1-left">
				<i class="fa fa-h-square"></i>
				<p>Get upto Rs.100 off on all Bus bookings</p>
				<h3>Get Rs.100 on Hotels + PayUMoney</h3>
				<h6>Valid till 30-Mar-2016</h6>
				<a href="#" class="off" data-toggle="modal" data-target="#myModal2">View Offer</a>
			</div>
		</div>
		<div class="col-md-4 wow fadeInRight animated" data-wow-delay=".5s">
			<div class="offers-1-left">
				<i class="fa fa-gift"></i>
				<p>Get upto Rs.100 off on all Bus bookings</p>
				<h3>Get Rs.100 on Hotels + PayUMoney</h3>
				<h6>Valid till 31-Mar-2016</h6>
				<a href="#" class="off" data-toggle="modal" data-target="#myModal2">View Offer</a>
			</div>
		</div>
		<div class="col-md-4 wow fadeInLeft animated" data-wow-delay=".5s">
			<div class="offers-1-left">
				<i class="fa fa-mobile"></i>
				<p>Get upto Rs.100 off on all Bus bookings</p>
				<h3>Get Rs.100 on Hotels + PayUMoney</h3>
				<h6>Valid till 2-Apr-2016</h6>
				<a href="#" class="off" data-toggle="modal" data-target="#myModal2">View Offer</a>
			</div>
		</div>
		<div class="col-md-4 wow fadeInUp animated" data-wow-delay=".5s">
			<div class="offers-1-left">
				<i class="fa fa-gift"></i>
				<p>Get upto Rs.100 off on all Bus bookings</p>
				<h3>Get Rs.100 on Hotels + PayUMoney</h3>
				<h6>Valid till 3-Apr-2016</h6>
				<a href="#" class="off" data-toggle="modal" data-target="#myModal2">View Offer</a>
			</div>
		</div>
		<div class="col-md-4 wow fadeInRight animated" data-wow-delay=".5s">
			<div class="offers-1-left">
				<i class="fa fa-usd"></i>
				<p>Get upto Rs.100 off on all Bus bookings</p>
				<h3>Get Rs.100 on Hotels + PayUMoney</h3>
				<h6>Valid till 4-Apr-2016</h6>
				<a href="#" class="off" data-toggle="modal" data-target="#myModal2">View Offer</a>
			</div>
		</div>
		<div class="clearfix"></div>
		<!-- mobile -->
			<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
						</div>
						<div class="modal-body">
							<ul class="off-mo">
								<li><span>1. </span>Flat USD. 100 discount. Discount valid on a minimum transaction of USD. 300</li>
								<li><span>2. </span>Valid for 1st time transactions and only on mobile application</li>
								<li><span>3. </span>Offer valid only for 1 transaction</li>
								<li><span>4. </span>Offer cannot be clubbed with any other offer</li>
								<li><span>5. </span>Offer not valid on mobile web, desktop site, Cash on Delivery, Phone booking</li>
								<li><span>6. </span>Ibibo Group Pvt. Ltd. reserves the right to end any or all offers at its discretion without any prior notice</li>
								<li><span>7. </span>All disputes subject to New Delhi Jurisdiction</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		<!-- //mobile -->
	</div>
</div>