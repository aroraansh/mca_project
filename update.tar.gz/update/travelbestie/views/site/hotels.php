<?php
use yii\helpers\Html;
use yii\helpers\Url;
?>

<!--- banner ---->
<div class="container">
	<div class="col-md-7 bann-info wow fadeInRight animated" data-wow-delay=".5s">
		<h2>Online Tickets with Zero Booking Fees</h2>
		<div class="ban-top">
			<div class="bnr-left">
				<input class="city" type="text" value="Enter City, Area or Hotel Name..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter City, Area or Hotel Name...';}" required=>
			</div>
			
				<div class="clearfix"></div>
		</div>
		<div class="ban-bottom">
			<div class="bnr-right">
			<form>
				<input class="date" id="datepicker" type="text" value="dd-mm-yyyy" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'dd-mm-yyyy';}" required=>
			</div>
			<div class="bnr-right">
				
				<input class="date" id="datepicker1" type="text" value="dd-mm-yyyy" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'dd-mm-yyyy';}" required=>
			</div>
			</form>
				<div class="clearfix"></div>
				<!---start-date-piker---->
				<link rel="stylesheet" href="css/jquery-ui.css" />
				<script src="js/jquery-ui.js"></script>
					<script>
						$(function() {
						$( "#datepicker,#datepicker1" ).datepicker();
						});
					</script>
			<!---/End-date-piker---->
		</div>
		<div class="sear">
			<form action="<?= Url::toRoute('site/details');?>">
				<button class="seabtn">Search Hotels</button>
			</form>
		</div>
	</div>
	<div class="clearfix"></div>
</div>
<!--- /banner ---->
<!--- rupes ---->
<div class="container">
	<div class="rupes">
		<div class="col-md-4 rupes-left wow fadeInLeft animated" data-wow-delay=".5s">
			<div class="rup-left">
				<a href="<?= Url::toRoute('site/offers'); ?>"><i class="fa fa-usd"></i></a>
			</div>
			<div class="rup-rgt">
				<h3>UP TO USD. 50 OFF</h3>
				<h4><a href="<?= Url::toRoute('site/offers'); ?>">TRAVEL SMART</a></h4>
				<p>CODE:YBMAR12<br>Book Using Pay Money</p>
			</div>
				<div class="clearfix"></div>
		</div>
		<div class="col-md-4 rupes-left wow fadeInUp animated" data-wow-delay=".5s">
			<div class="rup-left">
				<a href="<?= Url::toRoute('site/offers'); ?>"><i class="fa fa-h-square"></i></a>
			</div>
			<div class="rup-rgt">
				<h3>UP TO 70% OFF</h3>
				<h4><a href="<?= Url::toRoute('site/offers'); ?>">ON HOTELS ACROSS WORLD</a></h4>
				<p>Offer CODE:YBMAR12</p>
			</div>
				<div class="clearfix"></div>
		</div>
		<div class="col-md-4 rupes-left wow fadeInRight animated" data-wow-delay=".5s">
			<div class="rup-left">
				<a href="<?= Url::toRoute('site/offers'); ?>"><i class="fa fa-mobile"></i></a>
			</div>
			<div class="rup-rgt">
				<h3>FLAT USD. 50 OFF</h3>
				<h4><a href="<?= Url::toRoute('site/offers'); ?>">BUS APP OFFER</a></h4>
				<p>book via the yellow Bus App<br>CODE:YBMAR12</p>
			</div>
				<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
<!--- /rupes ---->
<!--- hotels-top ---->
<div class="hotels-top">
	<div class="container">
		<h3>Hotel Rooms</h3>
		<div class="col-md-6 hotels-right wow fadeInLeft animated" data-wow-delay=".5s">
			<a href="siglepage.html">
					<div class="view1 view1-sixth">
					<?= Html::img('@web/images/h5.jpg');?>
							<div class="mask">
								<h2>Residence Inn Deptford</h2>
							</div>
					</div>
				</a>
		</div>
		<div class="col-md-6 hotels-right wow fadeInRight animated" data-wow-delay=".5s">
			<a href="siglepage.html">
					<div class="view1 view1-sixth">
						<?= Html::img('@web/images/h1.jpg');?>
							<div class="mask">
								<h2>Residence Inn Deptford</h2>
							</div>
					</div>
				</a>
		</div>
			<div class="clearfix"></div>
		<div class="hotl-top">
			<div class="col-md-4 hotels-left wow fadeInLeft animated" data-wow-delay=".5s">
				<a href="siglepage.html">
					<div class="view1 view1-sixth">
						<?= Html::img('@web/images/h3.jpg');?>
							<div class="mask">
								<h2>Residence Inn Deptford</h2>
							</div>
					</div>
				</a>
			</div>
			<div class="col-md-4 hotels-left wow fadeInUp animated" data-wow-delay=".5s">
				<a href="siglepage.html">
					<div class="view1 view1-sixth">
						<?= Html::img('@web/images/h2.jpg');?>
							<div class="mask">
								<h2>Residence Inn Deptford</h2>
							</div>
					</div>
				</a>
			</div>
			<div class="col-md-4 hotels-left wow fadeInRight animated" data-wow-delay=".5s">
				<a href="siglepage.html">
					<div class="view1 view1-sixth">
						<?= Html::img('@web/images/h4.jpg');?>
							<div class="mask">
								<h2>Residence Inn Deptford</h2>
							</div>
					</div>
				</a>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<!--- /hotels-top ---->
<!--- hotels-top ---->
<div class="hotels-top">
	<div class="container">
	<h3>Touring Cities</h3>
		<div class="col-md-4 hotels-left wow fadeInLeft animated" data-wow-delay=".5s">
			<a href="details.html"><div class="view1 view1-sixth">
				<?= Html::img('@web/images/c4.jpg');?>
				<div class="mask">
                    <h2>Paterson Great Falls</h2>
                </div>
			</div>
			</a>
		</div>
		<div class="col-md-4 hotels-left wow fadeInUp animated" data-wow-delay=".5s">
			<a href="details.html">
				<div class="view1 view1-sixth">
					<?= Html::img('@web/images/c5.jpg');?>
						<div class="mask">
							<h2>Paterson Great Falls</h2>
						</div>
				</div>
			</a>
		</div>
		<div class="col-md-4 hotels-left wow fadeInRight animated" data-wow-delay=".5s">
			<a href="details.html">
				<div class="view1 view1-sixth">
					<?= Html::img('@web/images/c3.jpg');?>
						<div class="mask">
							<h2>Paterson Great Falls</h2>
						</div>
				</div>
			</a>
		</div>
			<div class="clearfix"></div>
		<div class="hotl-top">
			<div class="col-md-6 hotels-right wow fadeInLeft animated" data-wow-delay=".5s">
				<a href="details.html">
					<div class="view1 view1-sixth">
						<?= Html::img('@web/images/c1.jpg');?>
							<div class="mask">
								<h2>Paterson Great Falls</h2>
							</div>
					</div>
				</a>
			</div>
			<div class="col-md-6 hotels-right portfolio-item slideanim slide wow fadeInRight animated" data-wow-delay=".5s">
				<a href="details.html">
					<div class="view1 view1-sixth">
						<?= Html::img('@web/images/c2.jpg');?>
							<div class="mask">
								<h2>Paterson Great Falls</h2>
							</div>
					</div>
				</a>
			</div>
				<div class="clearfix"></div>
		</div>
	</div>
</div>
<!--- /hotels-top ---->
<!--- routes ---->
<div class="routes">
	<div class="container">
		<div class="col-md-4 hotes-left wow fadeInRight animated" data-wow-delay=".5s">
			<h3>5000 +</h3>
			<p>Cities with Hotels</p>
		</div>
		<div class="col-md-4 hotes-left wow fadeInUp animated" data-wow-delay=".5s">
			<h3>1900 +</h3>
			<p>Happy Customers</p>
		</div>
		<div class="col-md-4 hotes-left wow fadeInRight animated" data-wow-delay=".5s">
			<h3>7000+</h3>
			<p>Hotel Across World</p>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
<!--- /routes ---->





</body>
</html>