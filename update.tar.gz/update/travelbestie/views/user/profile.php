<?php
use yii\jui\DatePicker;
use yii\bootstrap\ActiveForm;
use yii\helpers\Html;

/*
 * use app\assets\LoginCss;
 * use yii\helpers\Html;
 *
 * LoginCss::register($this);
 */
$this->title = 'Users';
$this->params['breadcrumbs'][] = ['label' => 'Users', 'url' => ['index']];

?>
<div class="site-about">
	<div class="about">
		<div class="container">
			<div class="about-top wow zoomIn animated animated"
				data-wow-delay=".5s"
				style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">
				<h4>Welcome</h4>
				<h2><?=Yii::$app->user->identity->first_name?></h2>
				<p></p>
			</div>
			<div class="panel-body">

</div>
		</div>
	</div>
</div>