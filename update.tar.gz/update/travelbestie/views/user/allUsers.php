<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
use app\models\User;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $searchModel app\models\CitySearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
$this->title = 'Users';
$this->params['breadcrumbs'][] = ['label' => 'Users', 'url' => ['index']];
?>


<section class="content">

<div class="city-index">
<div class=" panel ">
			<div class=" panel ">
    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Users', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
 </div>
 </div>
 <div class="panel panel-margin">
			<div class="panel-body">
				<div class="content-section clearfix">
				<div class="table table-responsive">
    <?php Pjax::begin() ?>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            [
                'name' => 'check',
                'class' => 'yii\grid\CheckboxColumn',
            ],
            ['class' => 'yii\grid\SerialColumn'],
            'id',
            'first_name',
            //'last_name',
            'email:email',
            //'password',
            //'date_of_birth',
            //'gender',  
            'contact_no',
            //'address',
            //'latitude',
            //'lognitude',
            'city',
            //'country',
            //'pin_code',
//             'language',
//              'email_verified:email',
//              'profile_picture',
//              'tos',
            // 'role_id',
//              'state_id',
//              'type_id',
//              'last_visit_time',
//              'last_action_time',
//              'last_password_change',
//              'login_error_count',
//              'activation_key',
//              'timezone',
//               'created_on',
//               'updated_on',
//             'created_by_id',

            [
                'class' => 'yii\grid\ActionColumn',
                'header' => '<a>Actions</a>' 
            ],
        ],
    ]); ?>
    <?php Pjax::end() ?>
    </div>
</div>
</div>
</div>
</div>
</section>


			