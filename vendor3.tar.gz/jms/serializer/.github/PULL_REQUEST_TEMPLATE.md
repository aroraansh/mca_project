| Q             | A
| ------------- | ---
| Bug fix?      | yes/no
| New feature?  | yes/no
| Doc updated   | yes/no
| BC breaks?    | yes/no <!-- don't forget updating UPGRADING.md file -->
| Deprecations? | yes/no <!-- don't forget updating UPGRADING.md file -->
| Tests pass?   | yes/no
| Fixed tickets | #... <!-- #-prefixed issue number(s), if any -->
| License       | Apache-2.0

