<?php 
use yii\widgets\ActiveForm;
use yii\helpers\Html;
use app\models\User;

 $form = ActiveForm::begin(['options' =>['enctype'=>'multipart/form-data']]);?>
 
 
	<?= $form = dropDownList('listname', $choice, ['city'=>'City', 'full_name'=>'Name']); ?>
	 <?= Html::submitButton('Sort', ['class' => 'btn btn-primary', 'value'=>'sort', 'name'=>'submit'],['prompt'=>'Select Category']) ?>
	  <?php ActiveForm::end(); ?>
	 
	  
	  $select = 'full_name';
	  
	  if ($model->load(Yii::$app->request->post(('submit')=='sort')))
        {
            die("sort");
        }
	  
	  
	  
	  
	  $query = User::find();
        
        $pagination = new Pagination([
            'defaultPageSize' => 4,
            'totalCount' => $query->count(),
        ]);
        
        $countries = $query->orderBy('full_name')
        ->offset($pagination->offset)
        ->limit($pagination->limit)
        ->all();
        
        return $this->render('table', [
            'countries' => $countries,
            'pagination' => $pagination,
        ]);
      
        
        
        
        
         <?= LinkPager::widget(['pagination' => $pagination]) ?>
         
         
         
         
        
         
         
         
         
         
         