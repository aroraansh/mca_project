<?php
Yii::setAlias(@userImgPath, '/home/user4/Desktop/html/jmit/web/image//');
return [
    'adminEmail' => 'admin@example.com',
];
