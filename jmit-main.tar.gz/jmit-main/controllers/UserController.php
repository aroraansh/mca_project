<?php
namespace app\controllers;

use app\models\LoginForm;
use app\models\User;
use app\models\UserSearch;
use Yii;
use yii\bootstrap\ActiveForm;
use yii\filters\VerbFilter;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\Response;
use yii\web\UploadedFile;
use yii\data\Pagination;

/**
 * UserController implements the CRUD actions for User model.
 */
class UserController extends Controller
{

    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => [
                        'POST'
                    ]
                ]
            ]
        ];
    }

    /**
     * Lists all User models.
     *
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new UserSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'flag' => false
        ]);
    }

    public function actionProfile()
    {
        //die('profile update');
        $model = $this->findModel(\Yii::$app->user->id);
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            //die('profile');
            
            \Yii::$app->session->setFlash('success', "Your Profile Update Successfully");
        }
       
        return $this->render('profile', ['model'=>$model]);
    }
    public function actionDashboard()
    {
        return $this->render('dashboard');
    }
    public function actionTable()
    {
        $u_name = User::find()->orderBy(['full_name'=>SORT_ASC])->all();
        $gen = User::find()->where(['gender'=>'female'])->orderBy(['full_name'=>SORT_ASC])->all();
        
        $query = User::find();
        $pagination = new Pagination([
            'defaultPageSize' => 5,
            'totalCount' => $query->count(),
        ]);
        $useres = $query->orderBy('full_name')
        ->offset($pagination->offset)
        ->limit($pagination->limit)
        ->all();
        
        return $this->render('table',['user'=>$u_name,'users'=>$gen,'useres' => $useres,
            'pagination' => $pagination,]);
    }
    public function actionTypography()
    {
        return $this->render('typography');
    }
    public function actionIcon()
    {
        return $this->render('icon');
    }
    public function actionNotifications()
    {
        return $this->render('notifications');
    }

    /**
     * Displays a single User model.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id)
        ]);
    }

    /**
     * Creates a new User model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     *
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new User();
        
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect([
                'view',
                'id' => $model->id
            ]);
        } else {
            return $this->render('create', [
                'model' => $model
            ]);
        }
    }

    /**
     * Updates an existing User model.
     * If update is successful, the browser will be redirected to the 'view' page.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        //die('update');
        $model = $this->findModel($id);
        
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect([
                'view',
                'id' => $model->id
            ]);
        } else {
            return $this->render('update', [
                'model' => $model
            ]);
        }
    }

    /**
     * Deletes an existing User model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();
        
        return $this->redirect([
            'index'
        ]);
    }

    /**
     * Finds the User model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     *
     * @param integer $id
     * @return User the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = User::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    /**
     * Login action.
     *
     * @return Response
     */
    public function actionLogin()
    {
        //die("login");
        $this->layout = 'newlayout';
        if (! Yii::$app->user->isGuest) {
            return $this->goHome();
        }
        $model = new LoginForm();
        
        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            $user = $model->getUser();
            // $user = $model->generateAuthKey();
            
            if ($user && $model->login()) {
                //die("login");
                return $this->redirect([
                    'site/profile']);
            } else {
                print_r($model->getErrors());
            }
        }
        return $this->render('login', [
            'model' => $model
        ]);
    }
    
    
    /**
     * Logout action.
     *
     * @return Response
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();
        
        return $this->goHome();
    }
    
    
    /**
     * Signup action.
     *
     * @return Response
     */
    public function actionSignup()
    {
        //die("Sign Up");
        $this->layout = 'newlayout';
        $model = new User();
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            Yii::error($model);
            $model->validate();
            return ActiveForm::validate($model);
            // both ways not working the way it should
            // return $model->validate();
        }
        if ($model->load(Yii::$app->request->post())) {
            if ($model->validate()) {
                $model->setPassword($model->password);
                
                if ($model->save()) {
                    $studentId = $model->id;
                    $image = UploadedFile::getInstance($model, 'profile_pic');
                    $imgName = 'user_' . $studentId . '.' . $image->getExtension();
                    $image->saveAs(\Yii::getAlias('@userImgPath') . '/' . $imgName);
                    $model->profile_pic = $imgName;
                    $model->save();
                    
                    \Yii::$app->session->setFlash('success', "You are Signed Up Successfully. Please Login");
                    return $this->redirect([
                        'user/login'
                    ]);
                } else {
                    print_r($model->getErrors());
                }
            } else {
                print_r($model->getErrors());
                exit();
            }
        } else {
            return $this->render('signup', [
                'model' => $model
            ]);
        }
    }
}
