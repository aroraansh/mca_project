<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<link rel="apple-touch-icon" sizes="76x76"
	href="../assets/img/apple-icon.png" />
<link rel="icon" type="image/png" href="../assets/img/favicon.png" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

<title>Material Dashboard</title>

<meta
	content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0'
	name='viewport' />
<meta name="viewport" content="width=device-width" />

</head>

<body>


	<div class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-8">
					<div class="card">
						<div class="card-header" data-background-color="purple">
							<h4 class="title">Edit Profile</h4>
							<p class="category">Complete your profile</p>
						</div>
						<div class="card-content">
 <?php $form = ActiveForm::begin(['options' =>['enctype'=>'multipart/form-data']]); ?>								<div class="row">
									<div class="col-md-5">
										<div class="form-group label-floating">
											<label class="control-label">Toxsl Technology</label> <input
												type="text" class="form-control" disabled>
										</div>
									</div>

									<div class="col-md-4">
										<div class="form-group label-floating">
											<label class="control-label">Email address</label> <input
												type="email" class="form-control"
												value="<?php  print_r(Yii::$app->user->identity->email);?>"
												disabled>
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-6">
										<div class="form-group label-floating">
											<label class="control-label">First Name</label> <input
												type="text" class="form-control"
												value="<?php  print_r(Yii::$app->user->identity->full_name);?>">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group label-floating">
											<label class="control-label">Last Name</label> <input
												type="text" class="form-control">
										</div>
									</div>
								</div>

								<div class="row">

									<div class="col-md-6">
										<div class="form-group label-floating">
											<label class="control-label">Phone No.</label> <input
												type="number" class="form-control" value="">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group label-floating">
											<label class="control-label">Hobbies</label> <input
												type="text" class="form-control" value="">
										</div>
									</div>
								</div>


								<div class="row">
									<div class="col-md-12">
										<div class="form-group">
											<label class="control-label">D.O.B</label> <input type="date"
												class="form-control" value="">
										</div>
									</div>
								</div>



								<div class="row">
									<div class="col-md-12">
										<div class="form-group label-floating">
											<label class="control-label">Adress</label> <input
												type="text" class="form-control"
												value="<?php  print_r(Yii::$app->user->identity->address);?>">
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-4">
										<div class="form-group label-floating">
											<label class="control-label">City</label> <input type="text"
												class="form-control"
												value="<?php  print_r(Yii::$app->user->identity->city);?>">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group label-floating">
											<label class="control-label">Tehsil</label> <input
												type="text" class="form-control" value="">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group label-floating">
											<label class="control-label">District</label> <input
												type="text" class="form-control" value="">
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-4">
										<div class="form-group label-floating">
											<label class="control-label">State</label> <input type="text"
												class="form-control" value="">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group label-floating">
											<label class="control-label">Country</label> <input
												type="text" class="form-control"
												value="<?php  print_r(Yii::$app->user->identity->country);?>">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group label-floating">
											<label class="control-label">Pin Code</label> <input
												type="number" class="form-control"
												value="<?php  print_r(Yii::$app->user->identity->pincode);?>">
										</div>
									</div>
								</div>
								<label class="control-label">Add your work details</label>
								<div class="row">
									<div class="col-md-4">
										<div class="form-group label-floating">
											<label class="control-label">Company Name</label> <input
												type="text" class="form-control" value="">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group label-floating">
											<label class="control-label">Position</label> <input
												type="text" class="form-control" value="">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group label-floating">
											<label class="control-label">Location</label> <input
												type="text" class="form-control" value="">
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-12">
										<div class="form-group">
											<label>About Me</label>
											<div class="form-group label-floating">
												<textarea class="form-control" rows="5"><?php  print_r(Yii::$app->user->identity->about_me);?></textarea>
											</div>
										</div>
									</div>
								</div>
								
								
								<?= Html::submitButton('Update Profile', ['class' => 'btn btn-primary pull-right']) ?>
								<div class="clearfix"></div>
    <?php ActiveForm::end(); ?>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="card card-profile">
						<div class="card-avatar">
						   <?= Html::img(Url::to('@web/image/'.$model->profile_pic), ['alt' => 'My logo']) ?> 
						   


						</div>

						<div class="content">
							<h6 class="category text-gray">Welcome</h6>
							<h4 class="card-title"><?php  print_r(Yii::$app->user->identity->full_name);?></h4>
							<a href="#pablo" class="btn btn-primary btn-round">Follow</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>