<?php
use app\models\User;
use yii\helpers\Url;
use yii\widgets\ActiveForm;
use yii\helpers\Html;
use yii\widgets\LinkPager;
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png" />
	<link rel="icon" type="image/png" href="../assets/img/favicon.png" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>First Project</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
</head>

<body>

        <div class="content">
	            <div class="container-fluid">
	                <div class="row">
	                    <div class="col-md-12">
	                        <div class="card card-plain">
	                            <div class="card-header" data-background-color="purple">
	                                <h4 class="title">User Details</h4>
	                                <p class="category">User Sort by </p>

	   	                        </div>       
	                            
	                            <div class="card-content table-responsive">
	                                <table class="table table-hover">
	                                 <thead class="text-primary">
	                                    	<th>Name</th>
	                                    	<th>City</th>
											<th>Gender</th>
											<th>Education</th>
	                                    </thead>
	                                <?php
	                                   
	                                   foreach ($user as $u_name){
	                                   	                                
	                                ?>
	                                    
	                                    <tbody>
	                                        <tr>
	                                        	<td><?php print_r($u_name->full_name); ?></td>
	                                        	<td><?php print_r($u_name->city); ?></td>
	                                        	<td><?php print_r($u_name->gender); ?></td>
												<td><?php print_r($u_name->education); ?></td>
	                                        </tr>
	                                        
	                                    </tbody>
	                                    <?php } ?>
	                                </table>
									 <?= LinkPager::widget(['pagination' => $pagination]) ?>
	                            </div>
	                        </div>
	                    </div>

	                    <div class="col-md-12">
	                        <div class="card card-plain">
	                            <div class="card-header" data-background-color="purple">
	                                <h4 class="title">User Details</h4>
	                                <p class="category">Female User's Sort by Name.</p>
	                            </div>
	                            <div class="card-content table-responsive">
	                                <table class="table table-hover">
	                                <thead class="text-primary">
	                                    	<th>Name</th>
	                                    	<th>Gender</th>
	                                    	<th>Contact</th>
	                                    	<th>Email</th>
	                                    </thead>
	                                    <?php 
	                                
	                                       foreach ($users as $gen){
	                                
	                                    ?>
	                                    
	                                    <tbody>
	                                        <tr>
	                                        	<td><?php  print_r($gen->full_name); ?></td>
	                                        	<td><?php  print_r($gen->gender); ?></td>
	                                        	<td><?php  print_r($gen->contact_no); ?></td>
	                                        	<td><?php  print_r($gen->email); ?></td>
	                                        </tr>
	                                    </tbody>
	                                     
	                                    <?php } ?>
	                                </table>
	                                <?= LinkPager::widget(['pagination' => $pagination]) ?>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
</body>	
</html>
