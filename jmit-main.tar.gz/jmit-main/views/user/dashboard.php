<?php
use app\models\User;
use app\models\UserSearch;
use yii\helpers\ArrayHelper;
use yii\data\ArrayDataProvider;

?>
<div class="content">
<?php       
            $count = User::find()->count();
            $cnt_male = User::find()->where(['gender'=>'male'])->count();
            $cnt_female = User::find()->where(['gender'=>'female'])->count();
            $users = User::find()->limit(1)->orderBy(['id'=>SORT_DESC])->one();
?>
				<div class="container-fluid">
					<div class="row">
						<div class="col-lg-3 col-md-6 col-sm-6">
							<div class="card card-stats">
								<div class="card-header" data-background-color="orange">
									<i class="material-icons">content_copy</i>
								</div>
								<div class="card-content">
									<p class="category">Total User</p>
									<h4 class="title"><?= $count?></h4>
								</div>
								<div class="card-footer">
									<div class="stats">
										<i class="material-icons text-danger"></i>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-3 col-md-6 col-sm-6">
							<div class="card card-stats">
								<div class="card-header" data-background-color="green">
									<i class="material-icons">store</i>
								</div>
								<div class="card-content">
									<p class="category">Male User</p>
									<h4 class="title"><?= $cnt_male?></h4>
								</div>
								<div class="card-footer">
									<div class="stats">
										<i class="material-icons">date_range</i> 
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-3 col-md-6 col-sm-6">
							<div class="card card-stats">
								<div class="card-header" data-background-color="red">
									<i class="material-icons">info_outline</i>
								</div>
								<div class="card-content">
									<p class="category">Female User</p>
									<h4 class="title"><?= $cnt_female?></h4>
								</div>
								<div class="card-footer">
									<div class="stats">
										<i class="material-icons">local_offer</i>
									</div>
								</div>
							</div>
						</div>

						<div class="col-lg-3 col-md-6 col-sm-6">
							<div class="card card-stats">
								<div class="card-header" data-background-color="blue">
									<i class="fa-fa-twitter"></i>
								</div>
								<div class="card-content">
									<p class="category">Last Created User</p>
									<h4 class="title"><?= $users->full_name;?></h4>
								</div>
								<div class="card-footer">
									<div class="stats">
										<i class="material-icons">update</i>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4">
							<div class="card">
								<div class="card-header card-chart" data-background-color="green">
									<div class="ct-chart" id="dailySalesChart"></div>
								</div>
								<div class="card-content">
									<h4 class="title">Daily User</h4>
									<p class="category"><span class="text-success"><i class="fa fa-long-arrow-up"></i> 55%  </span> increase in today sales.</p>
								</div>
								<div class="card-footer">
									<div class="stats">
										<i class="material-icons">access_time</i> updated 4 minutes ago
									</div>
								</div>
							</div>
						</div>

						<div class="col-md-4">
							<div class="card">
								<div class="card-header card-chart" data-background-color="orange">
									<div class="ct-chart" id="emailsSubscriptionChart"></div>
								</div>
								<div class="card-content">
									<h4 class="title">Email Subscriptions</h4>
									<p class="category">Last Campaign Performance</p>
								</div>
								<div class="card-footer">
									<div class="stats">
										<i class="material-icons">access_time</i> campaign sent 2 days ago
									</div>
								</div>

							</div>
						</div>

						<div class="col-md-4">
							<div class="card">
								<div class="card-header card-chart" data-background-color="red">
									<div class="ct-chart" id="completedTasksChart"></div>
								</div>
								<div class="card-content">
									<h4 class="title">Completed Tasks</h4>
									<p class="category">Last Campaign Performance</p>
								</div>
								<div class="card-footer">
									<div class="stats">
										<i class="material-icons">access_time</i> campaign sent 2 days ago
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-lg-6 col-md-12">
							<div class="card">
	                            <div class="card-header" data-background-color="orange">
	                                <h4 class="title">Recent User</h4>
	                            </div>
	                            <div class="card-content table-responsive">
	                               <table class="table table-hover">
	                                    <thead class="text-warning">
	                                    
	                                    
	                                    
	                                        <th>Sr. No.</th>
	                                    	<th>Name</th>
	                                    	<th>City</th>
	                                    	<th>Blood Group</th>
	                                    </thead>
	                                    <tbody>
	                                    <?php 
						                  $detail = User::find()->limit(4)->orderBy(['id'=>SORT_DESC])->all();
						                ?>
	                                        <tr>
	                                        	<td>1</td>
	                                        	<td><?php print_r($detail[0]->full_name);?></td>
	                                        	<td><?php print_r($detail[0]->city);?></td>
	                                        	<td><?php print_r($detail[0]->blood_group);?></td>
	                                        </tr>
	                                        <tr>
	                                        	<td>2</td>
	                                        	<td><?php print_r($detail[1]->full_name);?></td>
	                                        	<td><?php print_r($detail[1]->city);?></td>
	                                        	<td><?php print_r($detail[1]->blood_group);?></td>
	                                        </tr>
	                                        <tr>
	                                        	<td>3</td>
	                                        	<td><?php print_r($detail[2]->full_name);?></td>
	                                        	<td><?php print_r($detail[2]->city);?></td>
	                                        	<td><?php print_r($detail[2]->blood_group);?></td>
	                                        </tr>
	                                        <tr>
	                                        	<td>4</td>
	                                        	<td><?php print_r($detail[3]->full_name);?></td>
	                                        	<td><?php print_r($detail[3]->city);?></td>
	                                        	<td><?php print_r($detail[3]->blood_group);?></td>
	                                        </tr>
	                                    </tbody>
	                                </table>    
	                            </div>
	                        </div>
						</div>
					</div>
					
					
					<div class="row">
<?php 
$searchModel = new UserSearch();
$dataProvider = $searchModel->search(Yii::$app->request->queryParams);

echo $this->render('index', [
    'searchModel' => $searchModel,
    'dataProvider' => $dataProvider,
    'flag'=>true
]);
	?>
					
					</div>
				</div>
			</div>