<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<link rel="apple-touch-icon" sizes="76x76"
	href="../assets/img/apple-icon.png" />
<link rel="icon" type="image/png" href="../assets/img/favicon.png" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

<title>Material Dashboard</title>

<meta
	content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0'
	name='viewport' />
<meta name="viewport" content="width=device-width" />

</head>

<body>


	<div class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-8">
					<div class="card">
						<div class="card-header" data-background-color="purple">
							<h4 class="title">Edit Profile</h4>
							<p class="category">Complete your profile</p>
						</div>
						<div class="card-content">
 <?php $form = ActiveForm::begin(['options' =>['enctype'=>'multipart/form-data']]); ?>	
 							
 <div class="row">
		<div class="col-md-6">
			<div class="form-group label-floating">								
				<?= $form->field($model, 'full_name')->textInput(['maxlength' => true]) ?>
			</div>
		</div>
		<div class="col-md-6">
			<div class="form-group label-floating">	
				<?= $form->field($model, 'email')->textInput(['maxlength' => true, 'disabled'=>true]) ?>
			</div>
		</div>
 </div>	
 <div class="row">
		<div class="col-md-6">
			<div class="form-group label-floating">
				<?= $form->field($model, 'gender')->radioList([ 'male' => 'Male', 'female' => 'Female']);?>								
				
			</div>
		</div>
		<div class="col-md-6">
			<div class="form-group label-floating">	
				<?= $form->field($model, 'education')->dropDownList([''=>'','10th'=>'10th','12th'=>'12th',
				                            'Graduation'=>'Graduation','Post Graduation'=>'Post Graduation' ]) ?>
            </div>
		</div>
 </div>	
 <div class="row">
		<div class="col-md-6">
			<div class="form-group label-floating">							
				<?= $form->field($model, 'hobbies')->textInput(['maxlength' => true]) ?>
			</div>
		</div>
		<div class="col-md-6">
			<div class="form-group label-floating">	
				 <?= $form->field($model, 'blood_group')->dropDownList([''=>'','A+'=>'A+','A-'=>'A-','B+'=>'B+'
				     ,'B-'=>'B-','AB+'=>'AB+','AB-'=>'AB-','O+'=>'O+','O-'=>'O-' ]) ?>
            </div>
		</div>
 </div>				
 <div class="row">
		<div class="col-md-12">
			<div class="form-group label-floating">								
				<?= $form->field($model, 'address')->textInput(['maxlength' => true]) ?>
			</div>
		</div>
 </div>	
 <div class="row">
		<div class="col-md-4">
			<div class="form-group label-floating">								
				<?= $form->field($model, 'city')->textInput(['maxlength' => true]) ?>
			</div>
		</div>
		<div class="col-md-4">
			<div class="form-group label-floating">								
				 <?= $form->field($model, 'country')->textInput(['maxlength' => true]) ?>
			</div>
		</div>
		<div class="col-md-4">
			<div class="form-group label-floating">								
				 <?= $form->field($model, 'pincode')->textInput(['maxlength' => true]) ?>
			</div>
		</div>
 </div>	  
<div class="row">
		<div class="col-md-6">
			<div class="form-group label-floating">								
				<?= $form->field($model, 'contact_no')->textInput(['maxlength' => true]) ?>
			</div>
		</div>
		<div class="col-md-6">
			<div class="form-group label-floating">								
				 <?= $form->field($model, 'language')->textInput(['maxlength' => true]) ?>
			</div>
		</div>
 </div>	
 <div class="row">
		<div class="col-md-12">
			<div class="form-group label-floating">								
				 <?= $form->field($model, 'about_me')->textarea(['maxlength' => true]) ?>
			</div>
		</div>
 </div>
 
    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary pull-right']) ?>
    </div>
    <?php ActiveForm::end(); ?>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="card card-profile">
						<div class="card-avatar">
						   <?= Html::img(Url::to('@web/image/'.$model->profile_pic), ['alt' => 'My logo']) ?> 
						   


						</div>

						<div class="content">
							<h6 class="category text-gray">Welcome</h6>
							<h4 class="card-title"><?php  print_r(Yii::$app->user->identity->full_name);?></h4>
							<a href="https://facebook.com" class="btn btn-primary btn-round">Follow</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>