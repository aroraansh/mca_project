<?php

/* @var $this \yii\web\View */
/* @var $content string */
use app\assets\AppAsset;
use app\widgets\Alert;
use yii\helpers\Html;
use yii\widgets\Breadcrumbs;

use yii\helpers\Url;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>

<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
<meta charset="<?= Yii::$app->charset ?>">
<meta charset="utf-8" />
<link rel="apple-touch-icon" sizes="76x76"
	href="../assets/img/apple-icon.png" />
<link rel="icon" type="image/png" href="../assets/img/favicon.png" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
      <link
	href="https://fonts.googleapis.com/icon?family=Material+Icons"
	rel="stylesheet">
	<!--  Google Maps Plugin    -->
<!-- 	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script> -->
</head>
<body>
<?php $this->beginBody() ?>



<!-- Body End Here -->



	<div class="wrapper">

		<div class="sidebar" data-color="purple"
			data-image="img/sidebar-1.jpg">
			<!--
		        Tip 1: You can change the color of the sidebar using: data-color="purple | blue | green | orange | red"

		        Tip 2: you can also add an image using data-image tag
		    -->

			<div class="logo">
				<a href="https://toxsl.com" class="simple-text"> ToXSL </a>
			</div>

			<div class="sidebar-wrapper">



				<ul class="nav">
					
					<li class="active"><a href="<?= Url::toRoute(['profile'])?>"> <i
							class="material-icons">person</i>
							<p>User Profile</p>
					</a></li>
					<li ><a
						href="<?= Url::toRoute(['dashboard'])?>"> <i
							class="material-icons">dashboard</i>
							<p>Dashboard</p>
					</a></li>
					<li><a href="<?= Url::toRoute(['table'])?>"> <i class="material-icons">content_paste</i>
							<p>Table List</p>
					</a></li>
					<li><a href="<?= Url::toRoute(['typography'])?>"> <i class="material-icons">library_books</i>
							<p>Typography</p>
					</a></li>
					<li><a href="<?= Url::toRoute(['icon'])?>"> <i class="material-icons">bubble_chart</i>
							<p>Icons</p>
					</a></li>
		<?php /*		<li><a href="<?= Url::toRoute(['maps'])?>"> <i class="material-icons">location_on</i>*/ ?>
<!-- 							<p>Maps</p> -->
<!-- 					</a></li> -->
					<li><a href="<?= Url::toRoute(['notifications'])?>"> <i
							class="material-icons text-gray">notifications</i>
							<p>Notifications</p>
					</a></li>
				</ul>
			</div>
		</div>





		<div class="main-panel">
			<nav class="navbar navbar-transparent navbar-absolute">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse">
							<span class="sr-only">Toggle navigation</span> <span
								class="icon-bar"></span> <span class="icon-bar"></span> <span
								class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="#">Hello</a>
					</div>
					<div class="collapse navbar-collapse">
						<ul class="nav navbar-nav navbar-right">
							<li><a href="#pablo" class="dropdown-toggle"
								data-toggle="dropdown"> <i class="material-icons">dashboard</i>
									<p class="hidden-lg hidden-md">Dashboard</p>
							</a></li>
							<li class="dropdown"><a href="#" class="dropdown-toggle"
								data-toggle="dropdown"> <i class="material-icons">notifications</i>
									<span class="notification">5</span>
									<p class="hidden-lg hidden-md">Notifications</p>
							</a>
								<ul class="dropdown-menu">
									<li><a href="#">Mike John responded to your email</a></li>
									<li><a href="#">You have 5 new tasks</a></li>
									<li><a href="#">You're now friend with Andrew</a></li>
									<li><a href="#">Another Notification</a></li>
									<li><a href="#">Another One</a></li>
								</ul></li>
							<li><a href="<?= Url::toRoute(['user/logout']) ?>" class=""
								data-toggle=> <i class="material-icons">person</i>
									<p class="hidden-lg hidden-md">Profile</p>
							</a></li>
						</ul>

						<form class="navbar-form navbar-right" role="search">
							<div class="form-group  is-empty">
								<input type="text" class="form-control" placeholder="Search"> <span
									class="material-input"></span>
							</div>
							<button type="submit"
								class="btn btn-white btn-round btn-just-icon">
								<i class="material-icons">search</i>
								<div class="ripple-container"></div>
							</button>
						</form>
					</div>
				</div>
			</nav>

			<div class="content">
        <?=Breadcrumbs::widget(['links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : []])?>
        <?= Alert::widget() ?>
        <?= $content ?>
    </div>
		

			<footer class="footer">
				<div class="container-fluid">
					<nav class="pull-left">
						<ul>
							<li><a href="#"> Home </a></li>
							<li><a href="#"> Company </a></li>
							<li><a href="#"> Portfolio </a></li>
							<li><a href="#"> Blog </a></li>
						</ul>
					</nav>
					<p class="copyright pull-right">
						&copy;
						<script>document.write(new Date().getFullYear())</script>
						<a href="https://toxsl.com">ToXSL</a>, made with
						love for a better web
					</p>
				</div>
			</footer>
		</div>
</div>
<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
