<?php
namespace app\models;

use Yii;

/**
 * This is the model class for table "user".
 *
 * @property integer $id
 * @property string $full_name
 * @property string $email
 * @property string $password
 * @property string $about_me
 * @property string $contact_no
 * @property string $address
 * @property string $city
 * @property string $country
 * @property string $pincode
 * @property string $language
 * @property string $auth_key
 */
class User extends \yii\db\ActiveRecord implements \yii\web\IdentityInterface
{

    public static function tableName()
    {
        return 'user';
    }

    /*
     * public $id;
     *
     * public $username;
     *
     * public $password;
     *
     *
     *
     * public $accessToken;
     *
     * private static $users = [
     * '100' => [
     * 'id' => '100',
     * 'username' => 'admin',
     * 'password' => 'admin',
     * 'authKey' => 'test100key',
     * 'accessToken' => '100-token'
     * ],
     * '101' => [
     * 'id' => '101',
     * 'username' => 'demo',
     * 'password' => 'demo',
     * 'authKey' => 'test101key',
     * 'accessToken' => '101-token'
     * ]
     * ];
     */
     public $authKey;
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [
                [
                    'full_name',
                    'email',
                    'password',     
                ],
                'required'
            ],
            [
                'email',
                'unique',
                'targetClass' => '\app\models\User',
                'message' => 'This Email is already taken'
            ],
            [
                [
                    'email'
                ],
                'email'
            ],
            [
                [
                    'contact_no',
                    'pincode'
                ],
                'integer'
            ],
            [
                [
                    'profile_pic',
                    'hobbies',
                    'gender',
                    'education',
                    'blood_group',
                ],
                'string'
            ],
            [
                [
                    'full_name',
                    'about_me',
                    'city',
                    'country',
                    'language',
                    'auth_key'
                ],
                'string',
                'max' => 255
            ],
            [
                [
                    'password'
                ],
                'string',
                'max' => 128
            ],
            [
                [
                    'address'
                ],
                'string',
                'max' => 512
            ]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'full_name' => 'Full Name',
            'email' => 'Email',
            'password' => 'Password',
            'about_me' => 'About Me',
            'contact_no' => 'Contact No',
            'address' => 'Address',
            'city' => 'City',
            'country' => 'Country',
            'pincode' => 'Pincode',
            'language' => 'Language',
            'auth_key' => 'Auth Key'
        ];
    }

    /**
     * @inheritdoc
     */
//     public static function findIdentity($id)
//     {
//         return isset(self::$users[$id]) ? new static(self::$users[$id]) : null;
//     }
    public static function findIdentity($id)
    {
        return static::findOne([
            'id' => $id
            // 'state_id' => self::STATE_ACTIVE
            
        ]);
    }
    /**
     * @inheritdoc
     */
//     public static function findIdentityByAccessToken($token, $type = null)
//     {
//         foreach (self::$users as $user) {
//             if ($user['accessToken'] === $token) {
//                 return new static($user);
//             }
//         }
        
//         return null;
//     }

    public static function findIdentityByAccessToken($token, $type = null)
    {
        echo "findIdentityByAccessToken";
        return static::findOne([
            'auth_key' => $token
            // 'state_id' => self::STATE_ACTIVE
        ]);
    }
    
    /**
     * Finds user by username
     *
     * @param string $username
     * @return static|null
     */
    // public static function findByUsername($username)
    // {
    // return self::findOne([
    // 'email' => $username
    // ]);
    // /* foreach (self::$users as $user) {
    // if (strcasecmp($user['username'], $username) === 0) {
    // return new static($user);
    // }
    // }
    
    // return null; */
    // }
    public static function findByUsername($username)
    {
        return static::findOne([
            'email' => $username
        ]);
    }

    public function getLoginUrl()
    {
        return Yii::$app->urlManager->createAbsoluteUrl([
            'user/login'
        ]);
    }

    /**
     * @inheritdoc
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @inheritdoc
     */
    public function getAuthKey()
    {
        return $this->auth_key;
    }

    /**
     * @inheritdoc
     */
    public function validateAuthKey($authKey)
    {
        return $this->authKey === $authKey;
    }

    /*
     * public function generateAuthKey()
     * {
     * $this->auth_key = \Yii::$app->security->generateRandomString();
     * }
     */
    
    /**
     * Generates password hash from password and sets it to the model
     *
     * @param string $password
     */
    public function setPassword($password)
    {
        $this->password = $this->hashPassword($password);
        ;
    }

    public function validatePassword($password)
    {
        return $this->password === $this->hashPassword($password);
    }

    public function hashPassword($password)
    {
        /* if (YII_ENV == 'dev') */
        return md5($password);
        return Yii::$app->security->generatePasswordHash(yii::$app->name . $password);
    }
/**
 * Validates password
 *
 * @param string $password
 *            password to validate
 * @return bool if password provided is valid for current user
 */
    /*
     * public function hashPassword($password)
     * {
     * return md5($password);
     * }
     */
    // public function validatePassword($password)
    // {
    // return $this->password === $password;
    // }
}
