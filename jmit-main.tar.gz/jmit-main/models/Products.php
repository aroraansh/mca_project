<?php
namespace app\models;

/**
 * This is the model class for table "products".
 *
 * @property integer $product_id
 * @property string $url
 * @property string $name
 * @property string $description
 * @property string $price
 * @property integer $visible
 */
class Products extends \yii\db\ActiveRecord
{

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'products';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [
                [
                    'url',
                    'name',
                    'description',
                    'price'
                ],
                'required'
            ],
            [
                [
                    'price'
                ],
                'number'
            ],
            [
                [
                    'visible'
                ],
                'integer'
            ],
            [
                [
                    'url'
                ],
                'string',
                'max' => 100
            ],
            [
                [
                    'name'
                ],
                'string',
                'max' => 50
            ],
            [
                [
                    'description'
                ],
                'string',
                'max' => 255
            ],
            [
                [
                    'url'
                ],
                'unique'
            ]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'product_id' => 'Product ID',
            'url' => 'Url',
            'name' => 'Name',
            'description' => 'Description',
            'price' => 'Price',
            'visible' => 'Visible'
        ];
    }
}
