<?php

namespace Mpdf\Tag;

class Summary extends BlockTag
{


}
