<?php

namespace Mpdf\Tag;

class I extends InlineTag
{


}
