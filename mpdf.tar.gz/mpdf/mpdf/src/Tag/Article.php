<?php

namespace Mpdf\Tag;

class Article extends BlockTag
{


}
