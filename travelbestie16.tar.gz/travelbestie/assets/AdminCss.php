<?php
/**
 * @link http://www.yiiframework.com/
 * @copyright Copyright (c) 2008 Yii Software LLC
 * @license http://www.yiiframework.com/license/
 */
namespace app\assets;

use yii\web\AssetBundle;

/**
 * Main application asset bundle.
 *
 * @author Qiang Xue <qiang.xue@gmail.com>
 * @since 2.0
 */
class AdminCss extends AssetBundle
{
    
    public $basePath = '@webroot';
    
    public $baseUrl = '@web';
    
    public $css = [
        'css/admincss/bootstrap.min.css',
        'css/admincss/font-awesome.min.css',
        'css/admincss/ionicons.min.css',
        'css/admincss/ionicons.css',
        'css/admincss/AdminLTE.min.css',
        'css/admincss/_all-skins.min.css',
        'css/admincss/morris.css',
        'css/admincss/jquery-jvectormap.css',
        'css/admincss/bootstrap-datepicker.min.css',
        'css/admincss/daterangepicker.css',
        'css/admincss/bootstrap3-wysihtml5.min.css',
        'css/admincss/style.css',
        'css/admincss/dataTables.bootstrap.min.css',
        '//fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic',
        '//code.ionicframework.com/ionicons/1.4.1/css/ionicons.min.css',
        
    ];
    
    public $js = [
        'js/adminjs/jquery.min.js',
        'js/adminjs/jquery-ui.min.js',
        'js/adminjs/bootstrap.min.js',
        'js/adminjs/raphael.min.js',
        'js/adminjs/morris.min.js',
        'js/adminjs/jquery.sparkline.min.js',
        'js/adminjs/jquery-jvectormap-1.2.2.min.js',
        'js/adminjs/jquery-jvectormap-world-mill-en.js',
        'js/adminjs/jquery.knob.min.js',
        'js/adminjs/moment.min.js',
        'js/adminjs/daterangepicker.js',
        'js/adminjs/bootstrap-datepicker.min.js',
        'js/adminjs/bootstrap3-wysihtml5.all.min.js',
        'js/adminjs/jquery.slimscroll.min.js',
        'js/adminjs/fastclick.js',
        'js/adminjs/adminlte.js',
        'js/adminjs/adminlte.min.js',
        'js/adminjs/Chart.js',
        'js/adminjs/dataTables.bootstrap.min.js',
        'js/adminjs/jquery.dataTables.min.js',
    ];
    
    public $depends = [
        'yii\web\YiiAsset',
        'yii\bootstrap\BootstrapAsset'
    ];
}
