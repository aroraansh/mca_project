<?php

/* @var $this \yii\web\View */
/* @var $content string */
use app\assets\GuestView;
use app\widgets\Alert;
use yii\bootstrap\Nav;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\Breadcrumbs;

GuestView::register($this);
$this->title = 'Travel Bestie';
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>


<link rel="stylesheet"
	href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta charset="<?= Yii::$app->charset ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
    
</head>
<body>
<?php $this->beginBody() ?>

<div class="top-header">
		<div class="container">
			
			
			<ul class="tp-hd-rgt wow fadeInRight animated"
				data-wow-delay=".5s">
				<li class="tol">Toll Number : 0184-22334455</li>
				<li class="sig"><a href="<?= Url::toRoute(['/user/signup']);?>" data-toggle="modal" data-target="#signupModal">Sign
						Up</a></li>
				<li>|</li>
				<li class="sigi"><a href="<?= Url::toRoute(['/user/login']);?>" data-toggle="modal" data-target="#myModal4">Sign
						In</a></li>
			</ul>
			
			<?php 
			     /* Modal::begin([
			         'header' => '<h4>signup</h4>',
			         'id' => 'myModal',
			         'size' => 'modal-lg',
			     ]);
			     echo "<div id='modalContent'></div>";
			     Modal::end(); */
			?>
		
           <div class="clearfix"></div>
		</div>
	</div>
	<!--- /top-header ---->
	<!--- header ---->
	<div class="header">
		<div class="container">
			<div class="logo wow fadeInDown animated" data-wow-delay=".5s">
				<?= Html::img('@web/images/logo.png', $option=['class'=>'img-responsive']);?>
			</div>
			<div class="bus wow fadeInUp animated" data-wow-delay=".5s">
				<a href="<?= Url::toRoute('site/index'); ?>">BUSES</a> 
				<a href="<?= Url::toRoute('site/hotels'); ?>">HOTELS</a>
			</div>
			<div class="lock fadeInDown animated" data-wow-delay=".5s">
				<li><i class="fa fa-lock"></i></li>
				<li><div class="securetxt">
						SAFE &amp; SECURE<br> ONLINE PAYMENTS
					</div></li>
				<div class="clearfix"></div>
			</div>

			<div class="clearfix"></div>
		</div>

		<!--- /header ---->
		<!--- footer-btm ---->
		<div class="footer-btm wow fadeInLeft animated" data-wow-delay=".5s">
			<div class="container">
				<div class="navigation">
					<nav class="navbar navbar-default">
						<!-- Brand and toggle get grouped for better mobile display -->
						<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed"
								data-toggle="collapse"
								data-target="#bs-example-navbar-collapse-1">
								<span class="sr-only">Toggle navigation</span> <span
									class="icon-bar"></span> <span class="icon-bar"></span> <span
									class="icon-bar"></span>
							</button>
						</div>
						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse nav-wil"
							id="bs-example-navbar-collapse-1">
							<nav class="cl-effect-1">
								<ul class="nav navbar-nav">
						<?php
						if (Yii::$app->user->isGuest) {
        
        echo Nav::widget([
            'options' => [
                'class' => 'navbar-nav'
            ],
            'items' => [
                [
                    'label' => 'Home',
                    'url' => [
                        'site/index'
                    ]
                ],
            /* [
                'label' => 'Profile',
                'url' => [
                    'user/profile'
                ]
            ], */
            [
                    'label' => 'About',
                    'url' => [
                        'site/about'
                    ]
                ],
                [
                    'label' => 'FAQ',
                    'url' => [
                        'site/faq'
                    ]
                ],
                [
                    'label' => 'Travels',
                    'url' => [
                        'site/travel'
                    ]
                ],
                [
                    'label' => 'Privacy Policy',
                    'url' => [
                        'site/privacy'
                    ]
                ],
                [
                    'label' => 'Agent Registration',
                    'url' => [
                        'site/agent'
                    ]
                ],
                [
                    'label' => 'Terms 	and Conditions',
                    'url' => [
                        'site/terms'
                    ]
                ],
                [
                    'label' => 'Contact Us',
                    'url' => [
                        'site/contact'
                    ]
                ],
                [
                    'label' => 'Feedback',
                    'url' => [
                        'site/feedback'
                    ]
                ]
            ]
        ]);
    }
    else {
        echo Nav::widget([
            'options' => [
                'class' => 'navbar-nav'
            ],
            'items' => [
                [
                    'label' => 'Home',
                    'url' => [
                        'site/index'
                    ]
                ],
                [
                 'label' => 'Profile',
                 'url' => [
                 'user/profile'
                 ]
                 ],
                [
                    'label' => 'About',
                    'url' => [
                        'site/about'
                    ]
                ],
                [
                    'label' => 'FAQ',
                    'url' => [
                        'site/faq'
                    ]
                ],
                [
                    'label' => 'Travels',
                    'url' => [
                        'site/travel'
                    ]
                ],
                [
                    'label' => 'Privacy Policy',
                    'url' => [
                        'site/privacy'
                    ]
                ],
                [
                    'label' => 'Agent Registration',
                    'url' => [
                        'site/agent'
                    ]
                ],
                [
                    'label' => 'Terms 	and Conditions',
                    'url' => [
                        'site/terms'
                    ]
                ],
                [
                    'label' => 'Contact Us',
                    'url' => [
                        'site/contact'
                    ]
                ],
                [
                    'label' => 'Feedback',
                    'url' => [
                        'site/feedback'
                    ]
                ],
                [
                    'label' => 'Demo',
                    'url' => [
                        'site/demo'
                    ]
                ]
            ]
        ]);
    }
    ?>
							</ul>
							</nav>
						</div>
						<!-- /.navbar-collapse -->
					</nav>
				</div>

				<div class="clearfix"></div>
			</div>
		</div>
		<div class="banner-2">
			<div class="container">
				<h1 class="wow zoomIn animated animated" data-wow-delay=".5s"
					style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">
					Travel Bestie - Best in Class for Travel & Hotels</h1>
			</div>
		</div>
	</div>
	<div class="container">
        <?=Breadcrumbs::widget(['links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : []])?>
        <?= Alert::widget() ?>
        <?= $content ?>
    </div>
	<div class="copy-right">
		<div class="container">

			<div class="footer-social-icons wow fadeInDown animated animated"
				data-wow-delay=".5s"
				style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">
				<ul>
					<li><a class="facebook" href="#"><span>Facebook</span></a></li>
					<li><a class="twitter" href="#"><span>Twitter</span></a></li>
					<li><a class="flickr" href="#"><span>Flickr</span></a></li>
					<li><a class="googleplus" href="#"><span>Google+</span></a></li>
					<li><a class="dribbble" href="#"><span>Dribbble</span></a></li>
				</ul>
			</div>
			<p class="wow zoomIn animated animated" data-wow-delay=".5s"
				style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">
				© 2012 Travel Bestie . All Rights Reserved | Design by <a
					href="http://w3layouts.com/" target="_blank">W3layouts</a>
			</p>
		</div>
	</div>



<!-- sign -->
			<div class="modal fade" id="signupModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
						
						</div>
							
					</div>
				</div>
			</div>
			
<!-- //sign -->
<!-- signin -->
		<div class="modal fade" id="myModal4" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog" role="document">
					<div class="modal-content modal-info">
						
						
					</div>
				</div>
			</div>
<!-- //signin -->

	

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
