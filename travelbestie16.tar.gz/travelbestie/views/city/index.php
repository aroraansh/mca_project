<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\CitySearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Cities';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="super-header">
	<div class="sub-header" id="top-div">
    	<div class="top-left">
   			 <h1><?= Html::encode($this->title) ?></h1>
			 <?php // echo $this->render('_search', ['model' => $searchModel]); ?>
		 </div>
         <div class="top-right">
            <p>
                <?= Html::a('', ['create'], ['class' => 'glyphicon glyphicon-plus']) ?>
            </p>
         </div>
     </div>
</div>

<div class="city-index">
<div class="panel panel-margin">
			<div class="panel-body">
				<div class="content-section clearfix">
				<div class="table table-responsive">
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'name',
            'state',
//             'state_id',
//             'type_id',
            'created_on',
//             'updated_on',
            'created_by_id',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
</div>
</div>
</div>
</div>