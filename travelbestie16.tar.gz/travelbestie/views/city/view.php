<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\City */

$this->title = $model->name;
$this->params['breadcrumbs'][] = ['label' => 'Cities', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="super-header">
	<div class="sub-header" id="top-div">
    	<div class="top-left">
            <h1><?= Html::encode($this->title) ?></h1>
        </div>
        <div class="top-right">
            <p>
                <?= Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
                <?= Html::a('Delete', ['delete', 'id' => $model->id], [
                    'class' => 'btn btn-danger',
                    'data' => [
                        'confirm' => 'Are you sure you want to delete this item?',
                        'method' => 'post',
                    ],
                ]) ?>
                <?= Html::a('Home', ['/city/index'], ['class'=>'btn btn-primary']) ?>
            </p>
         </div>
     </div>
</div>
<div class="panel">
		<div class=" panel-body">
			<div class="col-md-12">
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
//             'id',
            'name',
            'state',
           /*  'state_id',
            'type_id', */
            'created_on',
            'updated_on',
            'created_by_id',
        ],
    ]) ?>

</div>
</div>
</div>
