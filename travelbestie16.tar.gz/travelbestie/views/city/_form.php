<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\City */
/* @var $form yii\widgets\ActiveForm */
?>

	<div class="panel-body">
		

    <?php $form = ActiveForm::begin(); ?>

    <?//= $form->field($model, 'id')->textInput() ?>


	<?= $form->field($model, 'name', [ 'template' => '<div class="col-sm-6">{input}{error}</div>' ] )
            ->textInput ( [ 'maxlength' => true,'placeholder' => 'City' ] )->label ( false )?>   



    <?= $form->field($model, 'state', [ 'template' => '<div class="col-sm-6">{input}{error}</div>' ] )
            ->textInput ( [ 'maxlength' => true,'placeholder' => 'State' ] )->label ( false )?>


    <?//= $form->field($model, 'state_id')->textInput() ?>

    <?//= $form->field($model, 'type_id')->textInput() ?>

    <?//= $form->field($model, 'created_on')->textInput() ?>

    <?//= $form->field($model, 'updated_on')->textInput() ?>

    <?//= $form->field($model, 'created_by_id')->textInput() ?>


	<div class="col-md-6 col-md-offset-3 bottom-admin-button btn-space-bottom text-right">
 
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', 
                    ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    
    </div>
   
  <?php ActiveForm::end(); ?>
 </div>
