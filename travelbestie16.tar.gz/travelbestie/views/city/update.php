<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\City */

$this->title = 'Update City: ' . $model->name;
$this->params['breadcrumbs'][] = ['label' => 'Cities', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->name, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = 'Update';
?>

<div class="super-header">
	<div class="sub-header" id="top-div">
    	<div class="top-left">
            <h1><?= Html::encode($this->title) ?></h1>
        </div>
        <div class="top-right">
            <?= Html::a('Home', ['/city/index'], ['class'=>'btn btn-primary']) ?>
		</div>
    </div>
</div>

<div class="city-update">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
