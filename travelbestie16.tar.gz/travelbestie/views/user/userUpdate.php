<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\jui\DatePicker;


/* @var $this yii\web\View */
/* @var $model app\models\User */
/* @var $form yii\widgets\ActiveForm */
$this->title = 'Update "' . $model->first_name . '" Profile';
?>
<center><h1><?= Html::encode($this->title) ?></h1></center>
<div class="panel-body">
<div class="user-form">

<div class="col-md-6">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'first_name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'last_name')->textInput(['maxlength' => true]) ?>
	
	<?php
	
                echo $form->field($model, 'date_of_birth')
                    ->widget(DatePicker::className(), [
                    'dateFormat' => 'php:d-M-Y',
                    'options' => [
                        'class' => 'form-control'
                    ],
                    'clientOptions' => [
                        // 'minDate' => 0,
                        'changeMonth' => true,
                        'changeYear' => true
                    ]
                ])?>
    
   <?= $form->field($model, 'gender')->radioList([ '1' => 'Male', '0' => 'Female']);?>

    <?= $form->field($model, 'contact_no')->textInput(['maxlength' => true]) ?>

</div>
<div class="col-md-6">
	
    <?= $form->field($model, 'address')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'city')->textInput(['maxlength' => true]) ?>
    
    <?= $form->field($model, 'country')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'pin_code')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'profile_picture')->textInput(['maxlength' => true]) ?>

</div>
    <div class="form-group">
    <div class="col-md-6 col-md-offset-3 bottom-admin-button btn-space-bottom">
	<div class="form-group text-center">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
   		<?= Html::a('Back', ['/user/user-profile'], ['class'=>'btn btn-success']) ?>
    </div>
	</div>
	</div>
    <?php ActiveForm::end(); ?>
</div>
</div>
