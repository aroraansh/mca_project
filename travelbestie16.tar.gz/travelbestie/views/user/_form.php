<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\jui\DatePicker;


/* @var $this yii\web\View */
/* @var $model app\models\User */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="panel-body">
<div class="user-form">
<div class="col-md-6">

    <?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]); ?>

    <?= $form->field($model, 'first_name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'last_name')->textInput(['maxlength' => true]) ?>

    <?/* = $form->field($model, 'email')->textInput(['maxlength' => true]) */ ?>
	
	<?php
	
                echo $form->field($model, 'date_of_birth')
                    ->widget(DatePicker::className(), [
                    'dateFormat' => 'php:d-M-Y',
                    'options' => [
                        'class' => 'form-control'
                    ],
                    'clientOptions' => [
                        // 'minDate' => 0,
                        'changeMonth' => true,
                        'changeYear' => true
                    ]
                ])?>
    
   <?= $form->field($model, 'gender')->radioList([ '1' => 'Male', '0' => 'Female']);?>

    <?= $form->field($model, 'contact_no')->textInput(['maxlength' => true]) ?>
    
</div>
<div class="col-md-6">

	<?= $form->field($model, 'address')->textInput(['maxlength' => true]) ?>
    
   <?= $form->field($model, 'city')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'country')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'pin_code')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'profile_picture')->textInput(['maxlength' => true]) ?>

    <?/* = $form->field($model, 'tos')->textInput() */ ?>

    <?/* = $form->field($model, 'role_id')->textInput() */ ?>

    <?/* = $form->field($model, 'state_id')->textInput() */ ?>

    <?/* = $form->field($model, 'type_id')->textInput()  */?>

    <?/* = $form->field($model, 'last_visit_time')->textInput()  */?>

    <?/* = $form->field($model, 'last_action_time')->textInput() */ ?>

    <?/* = $form->field($model, 'last_password_change')->textInput() */ ?>

    <?/* = $form->field($model, 'login_error_count')->textInput() */ ?>

    <?/* = $form->field($model, 'activation_key')->textInput(['maxlength' => true]) */ ?>

    <?/* = $form->field($model, 'timezone')->textInput(['maxlength' => true]) */ ?>

    <?/* = $form->field($model, 'created_on')->textInput()  */?>

    <?/* = $form->field($model, 'updated_on')->textInput( )*/ ?>

    <?/* = $form->field($model, 'created_by_id')->textInput() */ ?>
</div>
    <div class="form-group">
    <div class="col-md-6 col-md-offset-3 bottom-admin-button btn-space-bottom">
	<div class="form-group text-center">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>
	</div>
	</div>
    <?php ActiveForm::end(); ?>
</div>
</div>
