<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model app\models\LoginForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\helpers\Url;
use app\assets\GuestView;

GuestView::register($this);
$this->title = 'Login';
//$this->params['breadcrumbs'][] = $this->title;
?>
<div class="user-form">
	<div class="panel-body">
		<div class="user-form">
			<div class="col-md-12">
			<div class="text-center">
    <h1><?= Html::encode($this->title) ?></h1>
    </div>
    

    <p>Please fill out the following fields to login:</p>
    
   

    <?php $form = ActiveForm::begin([
        'id' => 'login-form',
        'enableClientValidation' => true,
        'enableAjaxValidation' => false,
        'options' => [
            'class' => 'login-form form'
        ],
    ]); ?>
		<div class="imgcontainer">
   	 <?= Html::img('@web/images/AdminImg/avatar.png' , $option=['alt'=>'User' ,'class'=>'avatar']); ?>
  </div>
        <?= $form->field($model, 'username',[ 'template' => '<div class="col-sm-12">{input}{error}</div>' ])->textInput(['maxlength' => true,'placeholder' => 'Username'])->label ( false ) ?>

        <?= $form->field($model, 'password',[ 'template' => '<div class="col-sm-12">{input}{error}</div>' ])->passwordInput(['maxlength' => true,'placeholder' => 'Password'])->label ( false ) ?>
		
		<div class="row">
				<div class="col-md-6 padd-0">
					<div class="checkbox remember">
        <?php echo $form->field($model, 'rememberMe')->checkbox();?>
</div>
</div>
</div>
        
                <?=Html::submitButton ( 'Login', [ 'class' => 'btn btn-lg btn-block btn-success submit-btn','id' => 'login','name' => 'login-button' ] )?>
    <?php ActiveForm::end(); ?>
</div>
</div>
</div>
</div>