<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model app\models\User */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="user-form">
	<div class="panel-body">
		<div class="user-form">
		
		<div class="imgcontainer">
   			 <?= Html::img('@web/images/signupicon.png' , $option=['alt'=>'Signup' ,'class'=>'avatar']); ?>
 	    </div>
			
    <?php $form = ActiveForm::begin(['id' => 'login-form',
        'enableClientValidation' => true,
        'enableAjaxValidation' => true,
        'options' => [
            'class' => 'login-form form'
            ]
        ],
        ['options' => ['enctype' => 'multipart/form-data']]); ?>
	<div class="col-md-6">
    <?= $form->field($model, 'first_name', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ] )
            ->textInput ( [ 'maxlength' => true,'placeholder' => 'First Name' ] )->label ( false )?>

    <?= $form->field($model, 'last_name', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ] )
            ->textInput ( [ 'maxlength' => true,'placeholder' => 'Last Name' ] )->label ( false )?>

    <?= $form->field($model, 'email', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ] )
            ->textInput ( [ 'maxlength' => true,'placeholder' => 'Email' ] )->label ( false )?>

    <?= $form->field($model, 'password', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ] )
            ->PasswordInput ( [ 'maxlength' => true,'placeholder' => 'Password' ] )->label ( false )?>
    
   <?=$form->field ( $model, 'confirm_password', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ] )
        ->passwordInput ( [ 'maxlength' => true,'placeholder' => 'Confirm Password' ] )->label ( false )?>
        
    <?= $form->field($model, 'profile_picture', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ] )
	->fileInput([ 'maxlength' => true,'placeholder' => 'Profile Picture' ] )->label ( false ) ?>
	
</div>
<div class="col-md-6">
	
	<?= $form->field($model, 'gender', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ])
	           ->radioList([ '1' => 'Male', '0' => 'Female'])->label ( false );?>

    <?= $form->field($model, 'contact_no', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ] )
            ->textInput ( [ 'maxlength' => true,'placeholder' => 'Contact Number' ] )->label ( false )?>

    <?= $form->field($model, 'address', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ] )
            ->textInput ( [ 'maxlength' => true,'placeholder' => 'Address' ] )->label ( false )?>

    <?= $form->field($model, 'city', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ] )
            ->textInput ( [ 'maxlength' => true,'placeholder' => 'City' ] )->label ( false )?>

    <?= $form->field($model, 'country', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ] )
            ->textInput ( [ 'maxlength' => true,'placeholder' => 'Country' ] )->label ( false )?>

 </div>
			<div class="form-group">
				<div
					class="col-md-6 col-md-offset-3 bottom-admin-button btn-space-bottom">
					<div class="form-group text-center">

        <?= Html::submitButton($model->isNewRecord ? 'Create Account' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>
				</div>
			</div>
    <?php ActiveForm::end(); ?>
</div>
	</div>
</div>
<?/* =$form->field ( $model, 'confirm_password', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ] )
        ->passwordInput ( [ 'maxlength' => true,'placeholder' => 'Confirm Password' ] )->label ( false ) */?>