<?php

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;


/* @var $this yii\web\View */
/* @var $model app\models\User */

$this->title = 'Create User';
$this->params['breadcrumbs'][] = ['label' => 'Users', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="super-header">
	<div class="sub-header" id="top-div">
    	<div class="top-left">
            <h1><?= Html::encode($this->title) ?></h1>
        </div>
        <div class="top-right">
            <?= Html::a('Home', ['/user/allusers'], ['class'=>'btn btn-primary']) ?>
		</div>
    </div>
</div>
    
    
    
    <div class="user-form">
	<div class="panel-body">
	
	
		<div class="user-form">
			<div class="col-md-6">
    <?php $form = ActiveForm::begin(['id' => 'login-form',
        'enableClientValidation' => true,
        'enableAjaxValidation' => true,
        'options' => [
            'class' => 'login-form form'
            ]
        ]); ?>
	
    <?= $form->field($model, 'first_name', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ] )
            ->textInput ( [ 'maxlength' => true,'placeholder' => 'First Name' ] )->label ( false )?>

    <?= $form->field($model, 'last_name', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ] )
            ->textInput ( [ 'maxlength' => true,'placeholder' => 'Last Name' ] )->label ( false )?>

    <?= $form->field($model, 'email', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ] )
            ->textInput ( [ 'maxlength' => true,'placeholder' => 'Email' ] )->label ( false )?>

    <?= $form->field($model, 'password', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ] )
            ->PasswordInput ( [ 'maxlength' => true,'placeholder' => 'Password' ] )->label ( false )?>
    
   <?=$form->field ( $model, 'confirm_password', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ] )
        ->passwordInput ( [ 'maxlength' => true,'placeholder' => 'Confirm Password' ] )->label ( false )?>
	
</div>
<div class="col-md-6">


	<?= $form->field($model, 'profile_picture', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ] )
	->fileInput([ 'maxlength' => true,'placeholder' => 'Profile Picture' ] )->label ( false ) ?>

	
	<?= $form->field($model, 'gender', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ])
	           ->radioList([ '1' => 'Male', '0' => 'Female'])->label ( false );?>

    <?= $form->field($model, 'contact_no', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ] )
            ->textInput ( [ 'maxlength' => true,'placeholder' => 'Contact Number' ] )->label ( false )?>

    <?= $form->field($model, 'address', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ] )
            ->textInput ( [ 'maxlength' => true,'placeholder' => 'Address' ] )->label ( false )?>

    <?= $form->field($model, 'city', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ] )
            ->textInput ( [ 'maxlength' => true,'placeholder' => 'City' ] )->label ( false )?>

    <?= $form->field($model, 'country', [ 'template' => '<div class="col-sm-12">{input}{error}</div>' ] )
            ->textInput ( [ 'maxlength' => true,'placeholder' => 'Country' ] )->label ( false )?>

 </div>
			<div class="form-group">
				<div
					class="col-md-6 col-md-offset-3 bottom-admin-button btn-space-bottom">
					<div class="form-group text-center">

        <?= Html::submitButton($model->isNewRecord ? 'Create Account' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    	
    </div>
				</div>
			</div>
    <?php ActiveForm::end(); ?>
</div>
	</div>
</div>
    

