<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\User */

$this->title = 'Create your account';
?>



<div class="user-create">

	<div class="text-center">
    <h1><?= Html::encode($this->title) ?></h1>
    </div>

    <?=$this->render('_signupform', ['model' => $model])?>

</div>