<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\User */

$this->title = 'Update User: ' . $model->first_name;
$this->params['breadcrumbs'][] = ['label' => 'Users', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = 'Update';
?>

<div class="super-header">
	<div class="sub-header" id="top-div">
    	<div class="top-left">
            <h1><?= Html::encode($this->title) ?></h1>
        </div>
        <div class="top-right">
            <?= Html::a('Home', ['/user/allusers'], ['class'=>'btn btn-primary']) ?>
		</div>
    </div>
</div>
    


<div class="user-update">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
