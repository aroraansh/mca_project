<?php
use yii\helpers\Html;
?>
<div class="tracking">
	<div class="container">
		<div class="tracking-top">
			<div class="col-md-6 tracking-left wow fadeInLeft animated" data-wow-delay=".5s">
				<h3>Book your ticket</h3>
				<p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
			</div>
			<div class="col-md-6 tracking-right wow fadeInRight animated" data-wow-delay=".5s">
				<?= Html::img('@web/images/map1.png'); ?>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="tracking-midle">
			<div class="col-md-6 tracking-right wow fadeInLeft animated" data-wow-delay=".5s">
				<?= Html::img('@web/images/map1.png'); ?>
			</div>
			<div class="col-md-6 tracking-left wow fadeInRight animated" data-wow-delay=".5s">
				<h3>Boarding</h3>
				<p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="tracking-bottom">
			<div class="col-md-6 tracking-left wow fadeInLeft animated" data-wow-delay=".5s">
				<h3>Tracking</h3>
				<p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
			</div>
			<div class="col-md-6 tracking-right wow fadeInRight animated" data-wow-delay=".5s">
				<?= Html::img('@web/images/map1.png'); ?>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="tracking-botm1">
			
			<div class="col-md-6 tracking-right wow fadeInLeft animated" data-wow-delay=".5s">
				<?= Html::img('@web/images/map1.png'); ?>
			</div>
			<div class="col-md-6 tracking-left wow fadeInRight animated" data-wow-delay=".5s">
				<h3>Dropping</h3>
				<p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>