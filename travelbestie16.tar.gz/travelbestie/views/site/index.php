<?php

/* @var $this yii\web\View */
use yii\helpers\Html;
use yii\web\UrlManager;
use yii\helpers\Url;
?>

<div class="container">
	<div class="col-md-5 bann-info1 wow fadeInLeft animated"
		data-wow-delay=".5s">
<?= Html::img('@web/images/large_logo.png', $option=['class'=>'img-responsive']);  ?>
<h3>WORLD'S MOST TRAVEL BRAND</h3>
	</div>
	<div class="col-md-7 bann-info wow fadeInRight animated"
		data-wow-delay=".5s">
		<h2>Online Tickets with Zero Booking Fees</h2>
		<div class="ban-top">
			<div class="bnr-left">
				<label class="inputLabel">From</label> <input class="city"
					type="text" value="Enter a city" onfocus="this.value = '';"
					onblur="if (this.value == '') {this.value = 'Enter a city';}"
					required=>
			</div>
			<div class="bnr-left">
				<label class="inputLabel">To</label> <input class="city" type="text"
					value="Enter a city" onfocus="this.value = '';"
					onblur="if (this.value == '') {this.value = 'Enter a city';}"
					required=>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="ban-bottom">
			<div class="bnr-right">
				<label class="inputLabel">Date of Journey</label> <input
					class="date" id="datepicker" type="text" value="dd-mm-yyyy"
					onfocus="this.value = '';"
					onblur="if (this.value == '') {this.value = 'dd-mm-yyyy';}"
					required=>
			</div>
			<div class="bnr-right">
				<label class="inputLabel">Date of Return<span class="opt">&nbsp;(Optional)</span></label>
				<input class="date" id="datepicker1" type="text" value="dd-mm-yyyy"
					onfocus="this.value = '';"
					onblur="if (this.value == '') {this.value = 'dd-mm-yyyy';}"
					required=>
			</div>
			<div class="clearfix"></div>
			<!---start-date-piker---->
			<link rel="stylesheet" href="css/jquery-ui.css" />
			<script src="js/jquery-ui.js"></script>
			<script>
						$(function() {
						$( "#datepicker,#datepicker1" ).datepicker();
						});
					</script>
			<!---/End-date-piker---->
		</div>
		<div class="sear">
			<form action="<?= Url::toRoute('site/bus'); ?>">
				<button class="seabtn">Search Buses</button>
			</form>
		</div>
	</div>
	<div class="clearfix"></div>
</div>
<!--- /banner ---->
<!--- rupes ---->
<div class="container">
	<div class="rupes">
		<div class="col-md-4 rupes-left wow fadeInDown animated animated"
			data-wow-delay=".5s"
			style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">
			<div class="rup-left">
				<a href="<?= Url::toRoute('site/offers'); ?>"><i class="fa fa-usd"></i></a>
			</div>
			<div class="rup-rgt">
				<h3>UP TO USD. 50 OFF</h3>
				<h4>
					<a href="<?= Url::toRoute('site/offers'); ?>">TRAVEL SMART</a>
				</h4>
				<p>
					CODE:YBMAR12<br>Book Using Pay Money
				</p>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="col-md-4 rupes-left wow fadeInDown animated animated"
			data-wow-delay=".5s"
			style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">
			<div class="rup-left">
				<a href="<?= Url::toRoute('site/offers'); ?>"><i
					class="fa fa-h-square"></i></a>
			</div>
			<div class="rup-rgt">
				<h3>UP TO 70% OFF</h3>
				<h4>
					<a href="<?= Url::toRoute('site/offers'); ?>">ON HOTELS ACROSS
						WORLD</a>
				</h4>
				<p>Offer CODE:YBMAR12</p>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="col-md-4 rupes-left wow fadeInDown animated animated"
			data-wow-delay=".5s"
			style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">
			<div class="rup-left">
				<a href="<?= Url::toRoute('site/offers'); ?>"><i
					class="fa fa-mobile"></i></a>
			</div>
			<div class="rup-rgt">
				<h3>FLAT USD. 50 OFF</h3>
				<h4>
					<a href="<?= Url::toRoute('site/offers'); ?>">BUS APP OFFER</a>
				</h4>
				<p>CODE:YBMAR12</p>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
<!--- /rupes ---->
<!---holiday---->
<div class="container">
	<div class="holiday">
		<div class="col-md-3 holiday-left animated wow fadeInUp animated"
			data-wow-duration="1200ms" data-wow-delay="500ms"
			style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
			<?= Html::img('@web/images/4.jpg'); ?>
			
		</div>
		<div class="col-md-6 holiday-mid animated wow fadeInUp animated"
			data-wow-duration="1200ms" data-wow-delay="500ms"
			style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
			<h3>Travel Holiday Packages</h3>
			<p>Private Guide and Driver in any language and in any departure
				date. For more information please contact us....</p>
		</div>
		<div class="col-md-3 holiday-left animated wow fadeInUp animated"
			data-wow-duration="1200ms" data-wow-delay="500ms"
			style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
			<?= Html::img('@web/images/5.jpg'); ?>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
<!---/holiday---->
<!---track---->
<div class="container">
	<div class="track">
		<div class="col-md-6 track-right wow fadeInLeft animated"
			data-wow-delay=".5s">
			<a href="<?= Url::toRoute('site/track'); ?>"><?= Html::img('@web/images/map1.png',$option=['class'=>'img-responsive']); ?></a>
		</div>
		<div class="col-md-6 track-left wow fadeInRight animated"
			data-wow-delay=".5s">
			<h3>TRACK MY BUS</h3>
			<p>First of its own kind,bus tracking feature on bus</p>
			<a href="<?= Url::toRoute('site/track'); ?>" class="learn">Learn More</a>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
<!--- /track ---->
<!--- routes ---->
<div class="routes">
	<div class="container">
		<div class="col-md-4 routes-left wow fadeInRight animated"
			data-wow-delay=".5s">
			<div class="rou-left">
				<a href="#"><i class="fa fa-truck"></i></a>
			</div>
			<div class="rou-rgt wow fadeInDown animated" data-wow-delay=".5s">
				<h3>800</h3>
				<p>ROUTES</p>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="col-md-4 routes-left">
			<div class="rou-left">
				<a href="#"><i class="fa fa-user"></i></a>
			</div>
			<div class="rou-rgt">
				<h3>190</h3>
				<p>BUS OPERATORS</p>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="col-md-4 routes-left wow fadeInRight animated"
			data-wow-delay=".5s">
			<div class="rou-left">
				<a href="#"><i class="fa fa-ticket"></i></a>
			</div>
			<div class="rou-rgt">
				<h3>7,000+</h3>
				<p>TICKETS SOLD</p>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
<!--- /routes ---->
