<?php
?>
<?php $this->beginPage() ?>
<?php $this->beginBody() ?>
<div class="contact">
	<div class="container">
	<h3>Contact Us</h3>
		<div class="col-md-3 contact-left">
			<div class="con-top animated wow fadeInUp animated" data-wow-duration="1200ms" data-wow-delay="500ms" style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
				<h4>Chandigarh</h4>  
					<li>Sco-301/302,</li> 
					<li>Sector 38d,</li>
					<li>Chandigarh - 160036</li> 
					<li>Ph:4568956555 </li>
					<li>Call Centre Time : 7am to 11pm</li>
			</div>
			<div class="con-top animated wow fadeInUp animated" data-wow-duration="1200ms" data-wow-delay="500ms" style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
				<h4>Delhi</h4>
					<li>402 - Swarna Jayanti,</li>  
					<li>Sadan Deluxe, Dr. B.D. Marg,</li>
					<li>New Delhi 110001</li> 
					<li>Ph:23319163,</li>
					<li>Call Centre Time : 7am to 11pm</li>
			</div>
			<div class="con-top animated wow fadeInUp animated" data-wow-duration="1200ms" data-wow-delay="500ms" style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
				<h4>Hyderabad</h4>
					<li>72, Leela Society,</li>  
					<li>Mansarovar</li>   
					<li>Bengaluru - 315624</li>
					<li>Ph:5896589742</li>
					<li>Call Centre Time : 7am to 11pm</li>					
			</div>
			<div class="con-top animated wow fadeInUp animated" data-wow-duration="1200ms" data-wow-delay="500ms" style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
				<h4>Patna</h4>
					<li>51, Shanti Villas,</li> 
					<li>Nitika Nagar,</li>
					<li>Patna - 432870</li> 
					<li>Ph:2563589741 </li>
					<li>Call Centre Time : 7am to 11pm</li>
			</div>
		</div>
		<div class="col-md-3 contact-left">
			<div class="con-top animated wow fadeInUp animated" data-wow-duration="1200ms" data-wow-delay="500ms" style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
				<h4>Gandhinagar</h4>
					<li>2th Floor,IT Tower</li> 
					<li>Sector 16, BinodGarh,</li>
					<li>Gandhinagar - 539696</li>
					<li>Ph:4568975125 </li>
					<li>Call Centre Time : 7am to 11pm</li>					
			</div>
			<div class="con-top animated wow fadeInUp animated" data-wow-duration="1200ms" data-wow-delay="500ms" style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
				<h4>Shimla</h4>
					<li>SCO - 22,</li>
					<li>Deccan Gymkhana,</li> 
					<li>Shimla - 245351</li> 
					<li>Ph:2563145879 </li>
					<li>Call Centre Time : 7am to 11pm</li>
			</div>
			<div class="con-top animated wow fadeInUp animated" data-wow-duration="1200ms" data-wow-delay="500ms" style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
				<h4>Srinagar</h4>
					<li>102-104,</li>  
					<li>South Avenue,</li> 
					<li>Srinagar - 110011</li> 
					<li>Ph:1548975236 </li>
					<li>Call Centre Time : 7am to 11pm</li>
			</div>
			<div class="con-top animated wow fadeInUp animated" data-wow-duration="1200ms" data-wow-delay="500ms" style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
				<h4>Bangalooru</h4>
					<li>B-103, M.S. Flats,</li> 
					<li>B.K.S. Marg,</li> 
					<li>Bangalooru - 132041</li>
					<li>Ph:2589631478 </li>
					<li>Call Centre Time : 7am to 11pm</li>					
			</div>
		</div>
		<div class="col-md-3 contact-left animated wow fadeInUp animated" data-wow-duration="1200ms" data-wow-delay="500ms" style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
			<div class="con-top">
				<h4>Mumbai</h4>
					<li>AB-79,</li> 
					<li>Shahjahan Road,</li> 
					<li>Mumbai - 220043</li>
					<li>Ph:1478523698</li>
					<li>Call Centre Time : 7am to 11pm</li>
			</div>
			<div class="con-top animated wow fadeInUp animated" data-wow-duration="1200ms" data-wow-delay="500ms" style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
				<h4>Jaipur</h4>
					<li>1282 Freedom Lane</li> 
					<li>Shastri Nagar</li> 
					<li>Jaipur - 325466</li>
					<li>Ph:2589631478 </li>
					<li>Call Centre Time : 7am to 11pm</li>
			</div>
			<div class="con-top animated wow fadeInUp animated" data-wow-duration="1200ms" data-wow-delay="500ms" style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
				<h4>Gangtok</h4>
					<li>SCO 116</li> 
					<li>Mahatma Gandhi Marg</li> 
					<li>Gangtok - 737101</li>
					<li>Ph:3698521475 </li>
					<li>Call Centre Time : 7am to 11pm</li>					
			</div>
			<div class="con-top animated wow fadeInUp animated" data-wow-duration="1200ms" data-wow-delay="500ms" style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
				<h4>Chennai</h4>
					<li>11, Status Quo,</li> 
					<li>Sterling Road,</li> 
					<li>Chennai - 122143</li>
					<li>Ph:2589632587 </li>
					<li>Call Centre Time : 7am to 11pm</li>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="col-md-3 contact-left">
			<div class="con-top animated wow fadeInUp animated" data-wow-duration="1200ms" data-wow-delay="500ms" style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
				<h4>Lucknow</h4>
					<li>3A/5, Radha Krishna Bhawan,</li> 
					<li>Park Road,</li> 
					<li>Lucknow - 345322</li>
					<li>Ph:2451365890 </li>
					<li>Call Centre Time : 7am to 11pm</li>					
			</div>
			<div class="con-top animated wow fadeInUp animated" data-wow-duration="1200ms" data-wow-delay="500ms" style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
				<h4>Kolkata</h4>
					<li>Ground Floor, Shop No. 50,</li> 
					<li>Rashi Behari Avenue,</li> 
					<li>Kolkata - 134223</li> 
					<li>Ph:0793941234 </li>
					<li>Call Centre Time : 7am to 11pm</li>
			</div>
			<div class="con-top animated wow fadeInUp animated" data-wow-duration="1200ms" data-wow-delay="500ms" style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
				<h4>Raipur</h4>
					<li>SCO 203, Rishabh Nagar,</li> 
					<li>New Rajendra Nagar</li> 
					<li>Raipur - 299177</li>
					<li>Ph:3543941234 </li>
					<li>Call Centre Time : 7am to 11pm</li>
			</div>
			<div class="con-top animated wow fadeInUp animated" data-wow-duration="1200ms" data-wow-delay="500ms" style="visibility: visible; animation-duration: 1200ms; animation-delay: 500ms; animation-name: fadeInUp;">
				<h4>Dehradun</h4>
					<li>Vivek Vihar Pocket 1,</li> 
					<li>Khurbura Mohalla</li> 
					<li>Dehradun - 132004</li>
					<li>Ph:0239412345 </li>
					<li>Call Centre Time : 7am to 11pm</li>
			</div>
			<div class="clearfix"></div>
		</div>
			<div class="clearfix"></div>
	</div>
</div>
<?php $this->endBody() ?>
<?php $this->endPage() ?>