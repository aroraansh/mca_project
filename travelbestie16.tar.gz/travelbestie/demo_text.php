<?php 
//How to correct problem => 'from view click on manage takes to default index'



// Step 1. in your updateMenu Item function add this url to manage case
/* 'url' => [
    'manage',
    'role_id' => $model->role_id
], */



// Step 2. Add this function in controller
/* public function actionManage($role_id)
{
    $model = new User();
    $url = $model->manageIndex($role_id);
    
    return $this->redirect($url);
} */


//Step 3. Apublic function manageIndex($role_id)
/* public function manageIndex($role_id)
{
    switch ($role_id) {
        case User::ROLE_DRIVER:
            {
                return [
                    'driver'
                ];
            }
        case User::ROLE_WAREHOUSE:
            {
                return [
                    'warehouse'
                ];
            }
        case User::ROLE_VENDOR:
            {
                return [
                    'vendor'
                ];
            }
            
        default:
            {
                return [
                    'index'
                ];
            }
    }
} */
?>

<?php 
// problem => Not show one action on a perticular index only.
// Add this code in your _grid view, which is called by index.
[
'class' => 'app\components\TActionColumn',
'header' => '<a>Actions</a>',
'template'=>'{view}{delete}'  //Add only this line, write only those action which you want to show.       
]

?>