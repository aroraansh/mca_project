<?php
namespace app\models;

use Yii;

/**
 * This is the model class for table "city".
 *
 * @property integer $id
 * @property string $name
 * @property string $state
 * @property integer $state_id
 * @property integer $type_id
 * @property string $created_on
 * @property string $updated_on
 * @property integer $created_by_id
 *
 * @property User $createdBy
 * @property Hotels[] $hotels
 */
class City extends \yii\db\ActiveRecord
{

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'city';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [
                [
                    'name',
                    'state',
                    'created_on'
                ],
                'required'
            ],
            [
                [
                    'state_id',
                    'type_id',
                    'created_by_id'
                ],
                'integer'
            ],
            [
                [
                    'created_on',
                    'updated_on'
                ],
                'safe'
            ],
            [
                [
                    'name',
                    'state'
                ],
                'string',
                'max' => 255
            ],
            [
                [
                    'name'
                ],
                'unique'
            ],
            [
                [
                    'name',
                    'state',
                ],
                'match',
                'pattern' => '/^[a-zA-Z ]*$/',
                'message' => "Enter Character's Only",
            ],
            [
                [
                    'name',
                    'state'
                ],          
                'trim'
            ],
            [
                [
                    'created_by_id'
                ],
                'exist',
                'skipOnError' => true,
                'targetClass' => User::className(),
                'targetAttribute' => [
                    'created_by_id' => 'id'
                ]
            ]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'state' => 'State',
            'state_id' => 'State ID',
            'type_id' => 'Type ID',
            'created_on' => 'Created On',
            'updated_on' => 'Updated On',
            'created_by_id' => 'Created By'
        ];
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), [
            'id' => 'created_by_id'
        ]);
    }

    
    public function beforeValidate()
    {
        if($this->isNewRecord)
        {
            if ( !isset( $this->created_on )) $this->created_on = date( 'Y-m-d H:i:s');
            if ( !isset( $this->updated_on )) $this->updated_on = date( 'Y-m-d H:i:s');
            if ( !isset( $this->created_by_id )) $this->created_by_id = Yii::$app->user->id;
        }else{
            $this->updated_on = date( 'Y-m-d H:i:s');
        }
        return parent::beforeValidate();
    }
    
    
/**
 *
 * @return \yii\db\ActiveQuery
 */
    /*
     * public function getHotels()
     * {
     * return $this->hasMany(Hotels::className(), ['city_id' => 'id']);
     * }
     */
}
