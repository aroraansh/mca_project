<?php
/**
 * First Data Global Gateway
 */
namespace Omnipay\FirstData;

/**
 * First Data Global Gateway
 *
 * This gateway has been deprecated and is now called the "Payeezy" Gateway.
 */
class GlobalGateway extends PayeezyGateway
{
}
