<?php
namespace Omnipay\NetBanx\Message;

class HostedCompleteAuthorizeRequest extends HostedCompletePurchaseRequest
{
}
